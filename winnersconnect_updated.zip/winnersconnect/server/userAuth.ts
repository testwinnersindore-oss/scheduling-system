import { createHmac, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";

export const DASHBOARD_USER_COOKIE = "winners_dashboard_user";
const TOKEN_TTL_SECONDS = 60 * 60 * 12;
const TOKEN_SECRET = process.env.SESSION_SECRET || process.env.MASTER_ADMIN_PASSWORD || "winners-connect-development-secret";

export function hashDashboardPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const derived = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${derived}`;
}

export function verifyDashboardPassword(password: string, encoded: string | null | undefined): boolean {
  if (!encoded) return false;
  const [salt, expectedHex] = encoded.split(":");
  if (!salt || !expectedHex) return false;
  try {
    const actual = scryptSync(password, salt, 64);
    const expected = Buffer.from(expectedHex, "hex");
    return actual.length === expected.length && timingSafeEqual(actual, expected);
  } catch {
    return false;
  }
}

function signature(payload: string): string {
  return createHmac("sha256", TOKEN_SECRET).update(payload).digest("base64url");
}

export function createDashboardUserToken(userId: number): string {
  const expiresAt = Math.floor(Date.now() / 1000) + TOKEN_TTL_SECONDS;
  const payload = `${userId}.${expiresAt}`;
  return `${payload}.${signature(payload)}`;
}

export function getDashboardUserId(token: string | undefined): number | null {
  if (!token) return null;
  const [idText, expiresText, providedSignature] = token.split(".");
  const payload = `${idText}.${expiresText}`;
  if (!idText || !expiresText || !providedSignature || signature(payload) !== providedSignature) return null;
  const id = Number(idText);
  const expiresAt = Number(expiresText);
  if (!Number.isInteger(id) || id <= 0 || !Number.isFinite(expiresAt) || expiresAt < Math.floor(Date.now() / 1000)) return null;
  return id;
}
