import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import { attendance, auditLogs, courses as courseTable, faculties, facultyCourseMaps, lectureAssignments, notes, resources as resourceTable, ruleCatalog, scheduleEntries, users } from "../drizzle/schema";
import { adjustGeneratedRows, DEFAULT_RULES, generateScheduleRows, validateGeneratedRows, timeToMinutes } from "./scheduler";
import { createMasterAdminUnlockToken, isValidMasterAdminPassword, MASTER_ADMIN_COOKIE } from "./masterAdminAuth";
import { createDashboardUserToken, DASHBOARD_USER_COOKIE, hashDashboardPassword, verifyDashboardPassword } from "./userAuth";
import { and, desc, eq, inArray } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { z } from "zod";

const roleSchema = z.enum(["Master Admin", "Admin", "Teacher / Operator", "Analysis Dashboard", "Live Display"]);
type AppRole = z.infer<typeof roleSchema>;
const dateSchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);

function effectiveRole(user: { role?: string | null; appRole?: string | null } | null | undefined): AppRole {
  if (user?.appRole && roleSchema.options.includes(user.appRole as AppRole)) return user.appRole as AppRole;
  return user?.role === "admin" ? "Master Admin" : "Teacher / Operator";
}
function requireRole(user: { role?: string | null; appRole?: string | null } | null | undefined, roles: AppRole[]) {
  if (!roles.includes(effectiveRole(user))) throw new TRPCError({ code: user ? "FORBIDDEN" : "UNAUTHORIZED", message: `This action requires: ${roles.join(" or ")}` });
}
async function recordAudit(ctx: { user?: { id: number; name?: string | null } | null }, action: string, entity: string, entityId?: string, metadata?: string) {
  const db = await getDb();
  if (!db) return;
  await db.insert(auditLogs).values({ actorUserId: ctx.user?.id, actorName: ctx.user?.name ?? "System user", action, entity, entityId, metadata });
}

const fallbackRules = [
  { rule: "WORK_START", value: "08:00", description: "Faculty working window starts at 8:00 AM" },
  { rule: "WORK_END", value: "20:00", description: "Faculty working window ends at 8:00 PM" },
  { rule: "SETUP_BUFFER", value: "10", description: "Faculty setup/travel buffer total: 5 minutes before + 5 minutes after (minutes)" },
  { rule: "MAX_LECTURES", value: "8", description: "Maximum fixed lectures per faculty/day" },
  { rule: "ONLINE_RESOURCE", value: "STUDIO / ONLINE_ROOM", description: "Online classes require Studio or Online Room" },
  { rule: "OFFLINE_RESOURCE", value: "HALL", description: "Offline classes require Hall resource" },
];

const scheduleInput = z.object({
  id: z.number().optional(),
  scheduleDate: dateSchema,
  slotNumber: z.number().int().min(1).max(8),
  startTime: z.string(),
  endTime: z.string(),
  facultyId: z.number().int().positive(),
  facultyName: z.string().min(1),
  courseIds: z.string().min(1),
  courseNames: z.string().min(1),
  lectureTitle: z.string().min(1),
  subject: z.string().min(1),
  mode: z.enum(["online", "offline", "hybrid"]),
  platform: z.enum(["youtube", "app", "offline"]),
  resourceCode: z.string().nullable().optional(),
  resourceType: z.enum(["hall", "studio", "online_room"]).nullable().optional(),
  operatorName: z.string().nullable().optional(),
  pdfUploaded: z.number().int().min(0).max(1).default(0),
  pdfReceived: z.number().int().min(0).max(1).default(0),
  notes: z.string().nullable().optional(),
  status: z.enum(["ready", "warning", "replacement", "done", "cancelled"]).default("ready"),
  actualInTime: z.string().nullable().optional(),
  actualOutTime: z.string().nullable().optional(),
  actualDurationMinutes: z.number().int().nonnegative().nullable().optional(),
  reviewComplete: z.number().int().min(0).max(1).default(0),
  setupBufferMinutes: z.number().int().min(0).max(60).default(10),
  isCarryForward: z.number().int().min(0).max(1).default(0),
  carryForwardSourceDate: dateSchema.nullable().optional(),
  timeAdjustmentMinutes: z.number().int().min(-1440).max(1440).default(0),
});

const facultyImportSchema = z.object({ employeeCode: z.string().min(1), name: z.string().min(2), initials: z.string().min(1).max(120), primarySubject: z.string().min(1), defaultMode: z.enum(["online", "offline", "hybrid"]), availability: z.string().min(3), replacementEligible: z.number().int().min(0).max(1).default(1), maxLectures: z.number().int().positive().default(8), notes: z.string().nullable().optional() });
const courseImportSchema = z.object({ code: z.string().min(1), name: z.string().min(2), studentCount: z.number().int().min(0).default(0), subject: z.string().default("General"), branch: z.string().default("Indore"), mode: z.enum(["online", "offline", "hybrid"]), status: z.enum(["active", "draft", "archived"]).default("active"), notes: z.string().nullable().optional() });
const resourceImportSchema = z.object({ resourceCode: z.string().min(1), resourceName: z.string().min(2), type: z.enum(["hall", "studio", "online_room"]), buildingGroup: z.string().default("Main campus"), availabilityFrom: z.string().default("08:00"), availabilityTo: z.string().default("20:00"), status: z.enum(["available", "live", "maintenance"]).default("available"), notes: z.string().nullable().optional() });
function safeFacultyInitials(value: string, name: string) {
  const compact = value.trim().replaceAll(/[^A-Za-z]/g, "");
  if (compact.length >= 1 && compact.length <= 8 && compact.length === value.trim().length) return compact.toUpperCase();
  return name.split(/\s+/).filter(Boolean).map((part) => part[0]).join("").slice(0, 3).toUpperCase() || "FAC";
}
function safeFacultyAvailability(value: string) {
  return /^(present|available)$/i.test(value.trim()) ? "08:00–20:00" : value.trim().slice(0, 120) || "08:00–20:00";
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    verifyMasterAdminPassword: publicProcedure.input(z.object({ password: z.string().min(1).max(256) })).mutation(async ({ ctx, input }) => {
      if (!isValidMasterAdminPassword(input.password, process.env.MASTER_ADMIN_PASSWORD ?? "")) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Incorrect Master Admin password" });
      }
      ctx.res.cookie(MASTER_ADMIN_COOKIE, createMasterAdminUnlockToken(), { httpOnly: true, path: "/", sameSite: "none", secure: true, maxAge: 8 * 60 * 60 * 1000 });
      await recordAudit({ user: { id: 0, name: "Master Admin" } }, "Login", "auth", "master-admin");
      return { unlocked: true } as const;
    }),
    loginUser: publicProcedure.input(z.object({ loginId: z.string().min(1).max(120), password: z.string().min(1).max(256) })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "UNAUTHORIZED", message: "User login is not available until the database is connected" });
      const user = (await db.select().from(users).where(eq(users.loginId, input.loginId.trim())).limit(1))[0];
      if (!user || !verifyDashboardPassword(input.password, user.passwordHash)) throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid user ID or password" });
      ctx.res.cookie(DASHBOARD_USER_COOKIE, createDashboardUserToken(user.id), { httpOnly: true, path: "/", sameSite: "none", secure: true, maxAge: 12 * 60 * 60 * 1000 });
      await recordAudit({ user: { id: user.id, name: user.name ?? user.loginId } }, "Login", "auth", user.loginId ?? undefined);
      return { kind: "user" as const, role: user.appRole, roles: [user.appRole], name: user.name ?? user.loginId };
    }),
    logout: publicProcedure.mutation(async ({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      ctx.res.clearCookie(MASTER_ADMIN_COOKIE, { httpOnly: true, path: "/", sameSite: "none", secure: true, maxAge: -1 });
      ctx.res.clearCookie(DASHBOARD_USER_COOKIE, { httpOnly: true, path: "/", sameSite: "none", secure: true, maxAge: -1 });
      if (ctx.user) await recordAudit(ctx, "Logout", "auth", String(ctx.user.id));
      return { success: true } as const;
    }),
  }),
  winners: router({
    rules: publicProcedure.query(() => ({ ...DEFAULT_RULES, onlineResource: "STUDIO / ONLINE_ROOM", offlineResource: "HALL" })),
    bootstrap: publicProcedure.input(z.object({ date: dateSchema })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) return { source: "offline" as const, date: input.date, faculty: [], courses: [], mappings: [], resources: [], attendance: [], schedule: [], rules: fallbackRules };
      const [facultyRows, courseRows, mappingRows, resourceRows, attendanceRows, scheduleRows, ruleRows] = await Promise.all([
        db.select().from(faculties),
        db.select().from(courseTable),
        db.select().from(facultyCourseMaps),
        db.select().from(resourceTable),
        db.select().from(attendance).where(eq(attendance.attendanceDate, input.date)),
        db.select().from(scheduleEntries).where(and(eq(scheduleEntries.scheduleDate, input.date), eq(scheduleEntries.isDeleted, 0))),
        db.select().from(ruleCatalog),
      ]);
      return { source: "database" as const, date: input.date, faculty: facultyRows, courses: courseRows, mappings: mappingRows, resources: resourceRows, attendance: attendanceRows, schedule: scheduleRows, rules: ruleRows.length ? ruleRows : fallbackRules };
    }),
    users: protectedProcedure.query(async ({ ctx }) => { requireRole(ctx.user, ["Master Admin"]); const db = await getDb(); if (!db) return { users: [], source: "empty" as const }; return { users: await db.select({ id: users.id, loginId: users.loginId, name: users.name, email: users.email, dashboard: users.appRole }).from(users).orderBy(desc(users.createdAt)), source: "database" as const }; }),
    masterDataSnapshot: protectedProcedure.query(async ({ ctx }) => { requireRole(ctx.user, ["Master Admin", "Admin"]); const db = await getDb(); if (!db) return { source: "empty" as const, faculties: [], courses: [], mappings: [], resources: [] }; const [facultyRows, courseRows, mappingRows, resourceRows] = await Promise.all([db.select().from(faculties), db.select().from(courseTable), db.select().from(facultyCourseMaps), db.select().from(resourceTable)]); return { source: "database" as const, faculties: facultyRows, courses: courseRows, mappings: mappingRows, resources: resourceRows }; }),
    bulkUpsertMasterData: protectedProcedure.input(z.object({ faculties: z.array(facultyImportSchema).max(500).default([]), courses: z.array(courseImportSchema).max(500).default([]), resources: z.array(resourceImportSchema).max(500).default([]), mappings: z.array(z.object({ facultyId: z.number().int().positive(), courseId: z.number().int().positive(), allowed: z.number().int().min(0).max(1).default(1), priority: z.enum(["primary", "backup", "none"]).default("none"), notes: z.string().nullable().optional() })).max(1000).default([]) })).mutation(async ({ ctx, input }) => {
      requireRole(ctx.user, ["Master Admin"]);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Database is not connected. Permanent master-data save cannot continue." });
      try {
        const normalizedFaculties = input.faculties.map((row) => ({ ...row, initials: safeFacultyInitials(row.initials, row.name), availability: safeFacultyAvailability(row.availability) }));
        await db.transaction(async (tx) => {
          for (const row of normalizedFaculties) await tx.insert(faculties).values(row).onDuplicateKeyUpdate({ set: { name: row.name, initials: row.initials, primarySubject: row.primarySubject, defaultMode: row.defaultMode, availability: row.availability, replacementEligible: row.replacementEligible, maxLectures: row.maxLectures, notes: row.notes ?? null, active: 1 } });
          for (const row of input.courses) await tx.insert(courseTable).values(row).onDuplicateKeyUpdate({ set: { name: row.name, studentCount: row.studentCount, subject: row.subject, branch: row.branch, mode: row.mode, status: row.status, notes: row.notes ?? null, active: 1 } });
          for (const row of input.resources) await tx.insert(resourceTable).values(row).onDuplicateKeyUpdate({ set: { resourceName: row.resourceName, type: row.type, buildingGroup: row.buildingGroup, availabilityFrom: row.availabilityFrom, availabilityTo: row.availabilityTo, status: row.status, notes: row.notes ?? null } });
          if (input.mappings.length) await tx.insert(facultyCourseMaps).values(input.mappings);
        });
        await recordAudit(ctx, "Bulk imported permanent master data", "master-data", undefined, JSON.stringify({ faculties: input.faculties.length, courses: input.courses.length, resources: input.resources.length, mappings: input.mappings.length }));
      } catch (error) {
        console.error("[Master data] Bulk save failed", error);
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Master data save failed. Check the uploaded values and database schema, then retry." });
      }
      return { persisted: true, faculties: input.faculties.length, courses: input.courses.length, resources: input.resources.length, mappings: input.mappings.length };
    }),
    createUser: protectedProcedure.input(z.object({ name: z.string().min(2), email: z.string().email(), loginId: z.string().min(3).max(120), password: z.string().min(8).max(256), dashboard: roleSchema })).mutation(async ({ ctx, input }) => { requireRole(ctx.user, ["Master Admin"]); const db = await getDb(); if (db) await db.insert(users).values({ openId: `dashboard:${input.loginId}`, loginId: input.loginId, passwordHash: hashDashboardPassword(input.password), name: input.name, email: input.email, loginMethod: "master-admin", role: "user", appRole: input.dashboard }); await recordAudit(ctx, "Created dashboard user", input.loginId, undefined, JSON.stringify({ ...input, password: undefined })); return { loginId: input.loginId, dashboard: input.dashboard, created: true, persisted: Boolean(db) }; }),
    deleteUser: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => { requireRole(ctx.user, ["Master Admin"]); const db = await getDb(); if (db) await db.delete(users).where(eq(users.id, input.id)); await recordAudit(ctx, "Deleted dashboard user", String(input.id)); return { deleted: true, persisted: Boolean(db) }; }),
    courses: publicProcedure.query(async () => { const db = await getDb(); if (!db) return { courses: [], source: "empty" as const }; return { courses: await db.select().from(courseTable), source: "database" as const }; }),
    resources: publicProcedure.query(async () => { const db = await getDb(); if (!db) return { resources: [], source: "empty" as const }; return { resources: await db.select().from(resourceTable), source: "database" as const }; }),
    masterData: protectedProcedure.query(async ({ ctx }) => { requireRole(ctx.user, ["Master Admin", "Admin", "Analysis Dashboard"]); const db = await getDb(); if (!db) return { source: "empty" as const, rules: fallbackRules }; return { source: "database" as const, rules: await db.select().from(ruleCatalog) }; }),
    schedule: publicProcedure.input(z.object({ date: dateSchema })).query(async ({ input }) => { const db = await getDb(); if (!db) return { date: input.date, entries: [], source: "offline" as const, lunchLocked: false }; return { date: input.date, entries: await db.select().from(scheduleEntries).where(and(eq(scheduleEntries.scheduleDate, input.date), eq(scheduleEntries.isDeleted, 0))), source: "database" as const, lunchLocked: false }; }),
    validateSchedule: protectedProcedure.input(z.object({ date: dateSchema, slots: z.array(z.object({ facultyId: z.number(), startTime: z.string(), endTime: z.string(), mode: z.enum(["online", "offline", "hybrid"]), resourceType: z.enum(["hall", "studio", "online_room"]).nullable(), durationMinutes: z.number().positive() })).max(8) })).mutation(async ({ ctx, input }) => {
      requireRole(ctx.user, ["Master Admin", "Admin", "Analysis Dashboard"]);
      const warnings: string[] = [];
      const toMinutes = (value: string) => { const [hours, minutes] = value.split(":").map(Number); return Number.isFinite(hours) && Number.isFinite(minutes) ? hours * 60 + minutes : Number.NaN; };
      for (const item of input.slots) {
        const start = toMinutes(item.startTime); const end = toMinutes(item.endTime);
        if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) warnings.push(`Invalid time window ${item.startTime}–${item.endTime}`);
        if (start < 480 || end > 1200) warnings.push(`Class ${item.startTime}–${item.endTime} is outside WORK_START/WORK_END`);
        if (item.durationMinutes > 0 && end - start !== item.durationMinutes) warnings.push(`Class ${item.startTime}–${item.endTime} does not match its duration (${item.durationMinutes} minutes)`);
        if (item.mode === "online" && !["studio", "online_room"].includes(item.resourceType ?? "")) warnings.push("Online class requires STUDIO/online room");
        if (item.mode === "offline" && item.resourceType !== "hall") warnings.push("Offline class requires HALL resource");
      }
      await recordAudit(ctx, "Validated schedule", "schedule", input.date, JSON.stringify({ slots: input.slots.length, warnings }));
      return { date: input.date, valid: warnings.length === 0, warnings };
    }),
    generateSchedule: protectedProcedure.input(z.object({ date: dateSchema })).mutation(async ({ ctx, input }) => {
      requireRole(ctx.user, ["Master Admin", "Admin"]);
      const db = await getDb();
      if (!db) return { date: input.date, rows: [], warnings: ["Database is not configured; schedule generation requires a connected database"], generated: false, persisted: false, lunchLocked: false };
      const [facultyRows, courseRows, mappingRows, resourceRows, attendanceRows] = await Promise.all([
        db.select().from(faculties).where(eq(faculties.active, 1)),
        db.select().from(courseTable).where(eq(courseTable.active, 1)),
        db.select().from(facultyCourseMaps),
        db.select().from(resourceTable),
        db.select().from(attendance).where(eq(attendance.attendanceDate, input.date)),
      ]);
      const generated = generateScheduleRows({
        date: input.date,
        faculty: facultyRows.map(row => ({ id: row.id, name: row.name, subject: row.primarySubject, mode: row.defaultMode, availability: row.availability, maxLectures: row.maxLectures, active: row.active })),
        courses: courseRows.map(row => ({ id: row.id, code: row.code, name: row.name, subject: row.subject, mode: row.mode, active: row.active })),
        mappings: mappingRows.map(row => ({ facultyId: row.facultyId, courseId: row.courseId, allowed: row.allowed, priority: row.priority })),
        resources: resourceRows.map(row => ({ code: row.resourceCode, name: row.resourceName, type: row.type, status: row.status, availabilityFrom: row.availabilityFrom, availabilityTo: row.availabilityTo })),
        attendance: attendanceRows.map(row => ({ facultyId: row.facultyId, status: row.status, fromTime: row.fromTime, toTime: row.toTime })),
      });
      await db.delete(scheduleEntries).where(and(eq(scheduleEntries.scheduleDate, input.date), eq(scheduleEntries.isDeleted, 0)));
      if (generated.rows.length) await db.insert(scheduleEntries).values(generated.rows.map(row => ({ ...row, createdBy: ctx.user?.id ?? null })));
      await recordAudit(ctx, "Generated daily schedule", "schedule", input.date, JSON.stringify({ slots: generated.rows.length, warnings: generated.warnings, source: "automatic" }));
      const saved = await db.select().from(scheduleEntries).where(and(eq(scheduleEntries.scheduleDate, input.date), eq(scheduleEntries.isDeleted, 0)));
      return { date: input.date, rows: saved, warnings: generated.warnings, generated: saved.length > 0, persisted: true, lunchLocked: false };
    }),
    generateScheduleRange: protectedProcedure.input(z.object({ sourceDate: dateSchema, days: z.union([z.literal(1), z.literal(2), z.literal(3)]).default(3), adjustmentMinutes: z.number().int().min(-1440).max(1440).default(0), selectedIds: z.array(z.number().int().positive()).min(1).optional() })).mutation(async ({ ctx, input }) => {
      requireRole(ctx.user, ["Master Admin", "Admin"]);
      const db = await getDb();
      if (!db) return { persisted: false, dates: [], warnings: ["Database is not configured; multi-day scheduling requires a connected database"] };
      const activeSourceRows = await db.select().from(scheduleEntries).where(and(eq(scheduleEntries.scheduleDate, input.sourceDate), eq(scheduleEntries.isDeleted, 0)));
      const selectedRows = input.selectedIds?.length ? activeSourceRows.filter(row => input.selectedIds!.includes(row.id)) : activeSourceRows;
      if (!selectedRows.length) throw new TRPCError({ code: "BAD_REQUEST", message: "Select at least one class before scheduling the next three days." });
      const dates: string[] = [];
      const warnings: string[] = [];
      for (let offset = 1; offset <= input.days; offset += 1) {
        const target = new Date(`${input.sourceDate}T00:00:00Z`);
        target.setUTCDate(target.getUTCDate() + offset);
        const targetDate = target.toISOString().slice(0, 10);
        dates.push(targetDate);
        const rows = selectedRows.map((row, index) => ({
          scheduleDate: targetDate,
          slotNumber: index + 1,
          startTime: adjustGeneratedRows([{ ...row, durationMinutes: Math.max(0, timeToMinutes(row.endTime) - timeToMinutes(row.startTime)) } as any], targetDate, input.sourceDate, input.adjustmentMinutes)[0].startTime,
          endTime: adjustGeneratedRows([{ ...row, durationMinutes: Math.max(0, timeToMinutes(row.endTime) - timeToMinutes(row.startTime)) } as any], targetDate, input.sourceDate, input.adjustmentMinutes)[0].endTime,
          facultyId: row.facultyId,
          facultyName: row.facultyName,
          courseIds: row.courseIds,
          courseNames: row.courseNames,
          lectureTitle: row.lectureTitle,
          subject: row.subject,
          mode: row.mode,
          platform: row.platform,
          resourceCode: row.resourceCode,
          resourceType: row.resourceType,
          operatorName: row.operatorName,
          pdfUploaded: row.pdfUploaded,
          pdfReceived: row.pdfReceived,
          notes: `Carried forward from ${input.sourceDate}${input.adjustmentMinutes ? ` · adjusted ${input.adjustmentMinutes > 0 ? "+" : ""}${input.adjustmentMinutes} minutes` : ""}`,
          status: row.status,
          actualInTime: null,
          actualOutTime: null,
          actualDurationMinutes: row.actualDurationMinutes,
          reviewComplete: 0,
          setupBufferMinutes: row.setupBufferMinutes,
          isCarryForward: 1,
          carryForwardSourceDate: input.sourceDate,
          timeAdjustmentMinutes: input.adjustmentMinutes,
          createdBy: ctx.user?.id ?? null,
        }));
        const candidateRows = rows.map(row => ({ ...row, durationMinutes: Math.max(0, timeToMinutes(row.endTime) - timeToMinutes(row.startTime)) }));
        const ruleWarnings = validateGeneratedRows(candidateRows as any, DEFAULT_RULES);
        warnings.push(...ruleWarnings.map(w => `${targetDate}: ${w}`));
        await db.delete(scheduleEntries).where(and(eq(scheduleEntries.scheduleDate, targetDate), eq(scheduleEntries.isDeleted, 0)));
        if (rows.length) await db.insert(scheduleEntries).values(rows);
      }
      await recordAudit(ctx, "Generated selected classes for next three days", "schedule", input.sourceDate, JSON.stringify({ dates, adjustmentMinutes: input.adjustmentMinutes, selectedIds: input.selectedIds ?? selectedRows.map(row => row.id) }));
      return { persisted: true, dates, warnings, adjustmentMinutes: input.adjustmentMinutes, sourceRows: selectedRows.length };
    }),
    listScheduleBin: protectedProcedure.input(z.object({ date: dateSchema.optional() }).optional()).query(async ({ ctx, input }) => {
      requireRole(ctx.user, ["Master Admin", "Admin"]);
      const db = await getDb();
      if (!db) return { source: "empty" as const, entries: [] };
      const filters = [eq(scheduleEntries.isDeleted, 1)];
      if (input?.date) filters.push(eq(scheduleEntries.scheduleDate, input.date));
      return { source: "database" as const, entries: await db.select().from(scheduleEntries).where(and(...filters)).orderBy(desc(scheduleEntries.deletedAt), desc(scheduleEntries.id)) };
    }),
    deleteScheduleEntries: protectedProcedure.input(z.object({ ids: z.array(z.number().int().positive()).min(1), mode: z.enum(["bin", "permanent"]) })).mutation(async ({ ctx, input }) => {
      requireRole(ctx.user, ["Master Admin", "Admin"]);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Database is not connected" });
      if (input.mode === "bin") {
        await db.update(scheduleEntries).set({ isDeleted: 1, deletedAt: new Date(), deletedBy: ctx.user?.id ?? null }).where(and(eq(scheduleEntries.isDeleted, 0), inArray(scheduleEntries.id, input.ids)));
        await recordAudit(ctx, "Moved schedule class to Bin", "schedule", input.ids.join(","), JSON.stringify({ ids: input.ids, mode: "bin" }));
        return { deleted: input.ids.length, mode: "bin" as const };
      }
      await db.delete(scheduleEntries).where(inArray(scheduleEntries.id, input.ids));
      await recordAudit(ctx, "Permanently deleted schedule class", "schedule", input.ids.join(","), JSON.stringify({ ids: input.ids, mode: "permanent" }));
      return { deleted: input.ids.length, mode: "permanent" as const };
    }),
    restoreScheduleEntries: protectedProcedure.input(z.object({ ids: z.array(z.number().int().positive()).min(1) })).mutation(async ({ ctx, input }) => {
      requireRole(ctx.user, ["Master Admin", "Admin"]);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Database is not connected" });
      await db.update(scheduleEntries).set({ isDeleted: 0, deletedAt: null, deletedBy: null }).where(and(eq(scheduleEntries.isDeleted, 1), inArray(scheduleEntries.id, input.ids)));
      await recordAudit(ctx, "Restored schedule class from Bin", "schedule", input.ids.join(","), JSON.stringify({ ids: input.ids }));
      return { restored: input.ids.length };
    }),
    replaceSchedule: protectedProcedure.input(z.object({ date: dateSchema, entries: z.array(scheduleInput).max(500) })).mutation(async ({ ctx, input }) => {
      requireRole(ctx.user, ["Master Admin", "Admin", "Teacher / Operator"]);
      const lectureCounts = new Map<number, number>();
      input.entries.forEach((entry) => lectureCounts.set(entry.facultyId, (lectureCounts.get(entry.facultyId) ?? 0) + 1));
      if ([...lectureCounts.values()].some((count) => count > DEFAULT_RULES.maxLectures)) throw new TRPCError({ code: "BAD_REQUEST", message: `Each faculty member can have a maximum of ${DEFAULT_RULES.maxLectures} lectures per day` });
      const db = await getDb();
      if (!db) return { date: input.date, persisted: false, entries: input.entries };
      const existing = await db.select({ reviewComplete: scheduleEntries.reviewComplete }).from(scheduleEntries).where(eq(scheduleEntries.scheduleDate, input.date));
      const effectiveRole = ctx.user?.appRole || ctx.user?.role;
      if (effectiveRole !== "Master Admin" && existing.some((entry) => entry.reviewComplete)) throw new TRPCError({ code: "FORBIDDEN", message: "Completed classes are locked for operators. Ask Master Admin to edit them." });
      await db.delete(scheduleEntries).where(and(eq(scheduleEntries.scheduleDate, input.date), eq(scheduleEntries.isDeleted, 0)));
      if (input.entries.length) await db.insert(scheduleEntries).values(input.entries.map(({ id: _id, ...row }) => ({ ...row, createdBy: ctx.user?.id ?? null })));
      await recordAudit(ctx, "Saved date-wise schedule", "schedule", input.date, JSON.stringify({ slots: input.entries.length, source: "manual" }));
      return { date: input.date, persisted: true, entries: await db.select().from(scheduleEntries).where(and(eq(scheduleEntries.scheduleDate, input.date), eq(scheduleEntries.isDeleted, 0))) };
    }),
    updateScheduleEntry: protectedProcedure.input(scheduleInput.extend({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      requireRole(ctx.user, ["Master Admin", "Admin", "Teacher / Operator"]);
      const db = await getDb();
      const { id, scheduleDate: _date, ...patch } = input;
      if (db) {
        const current = await db.select({ reviewComplete: scheduleEntries.reviewComplete, isDeleted: scheduleEntries.isDeleted }).from(scheduleEntries).where(and(eq(scheduleEntries.id, id), eq(scheduleEntries.isDeleted, 0))).limit(1);
        const effectiveRole = ctx.user?.appRole || ctx.user?.role;
        if (current[0]?.isDeleted) throw new TRPCError({ code: "NOT_FOUND", message: "This class is in Bin and cannot be edited until restored." });
        if (effectiveRole !== "Master Admin" && current[0]?.reviewComplete) throw new TRPCError({ code: "FORBIDDEN", message: "Completed classes are locked for operators. Ask Master Admin to edit them." });
        await db.update(scheduleEntries).set(patch).where(eq(scheduleEntries.id, id));
      }
      await recordAudit(ctx, "Updated schedule entry", "schedule", String(id), JSON.stringify(patch));
      return { id, persisted: Boolean(db) };
    }),
    markAttendance: protectedProcedure.input(z.object({ facultyId: z.number(), status: z.enum(["present", "absent", "pending"]), date: dateSchema, fromTime: z.string().optional(), toTime: z.string().optional(), replacementMode: z.enum(["not_required", "required", "assigned"]).optional(), notes: z.string().optional() })).mutation(async ({ ctx, input }) => { requireRole(ctx.user, ["Master Admin", "Admin", "Teacher / Operator"]); const db = await getDb(); if (db) await db.insert(attendance).values({ facultyId: input.facultyId, attendanceDate: input.date, status: input.status, markedBy: ctx.user?.id, fromTime: input.fromTime ?? "08:00", toTime: input.toTime ?? "20:00", replacementMode: input.replacementMode ?? (input.status === "absent" ? "required" : "not_required"), notes: input.notes }); await recordAudit(ctx, "Marked attendance", "faculty", String(input.facultyId), JSON.stringify(input)); return { ...input, updated: true, persisted: Boolean(db) }; }),
    substituteCandidates: protectedProcedure.input(z.object({ subject: z.string() })).query(async ({ ctx, input }) => { requireRole(ctx.user, ["Master Admin", "Admin", "Teacher / Operator"]); const db = await getDb(); if (!db) return { subject: input.subject, candidates: [] }; const rows = await db.select({ id: faculties.id, name: faculties.name, initials: faculties.initials, subject: faculties.primarySubject }).from(faculties).where(eq(faculties.primarySubject, input.subject)).limit(5); return { subject: input.subject, candidates: rows }; }),
    updateFaculty: protectedProcedure.input(z.object({ id: z.number(), primarySubject: z.string().min(2), defaultMode: z.enum(["online", "offline", "hybrid"]), availability: z.string().min(3) })).mutation(async ({ ctx, input }) => { requireRole(ctx.user, ["Master Admin", "Admin"]); const db = await getDb(); if (db) await db.update(faculties).set({ primarySubject: input.primarySubject, defaultMode: input.defaultMode, availability: input.availability }).where(eq(faculties.id, input.id)); await recordAudit(ctx, "Updated faculty master", "faculty", String(input.id), JSON.stringify(input)); return { updated: true, persisted: Boolean(db) }; }),
    createFaculty: protectedProcedure.input(z.object({ employeeCode: z.string(), name: z.string(), initials: z.string(), primarySubject: z.string(), defaultMode: z.enum(["online", "offline", "hybrid"]), availability: z.string() })).mutation(async ({ ctx, input }) => { requireRole(ctx.user, ["Master Admin"]); const db = await getDb(); if (db) await db.insert(faculties).values(input); await recordAudit(ctx, "Created faculty master", input.employeeCode, undefined, JSON.stringify(input)); return { created: true, persisted: Boolean(db) }; }),
    audit: protectedProcedure.input(z.object({ limit: z.number().min(1).max(200).default(50) }).optional()).query(async ({ ctx, input }) => { requireRole(ctx.user, ["Master Admin", "Admin", "Analysis Dashboard"]); const db = await getDb(); if (!db) return { entries: [], source: "empty" as const }; return { entries: await db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(input?.limit ?? 50), source: "auditLogs" as const }; }),
    notes: protectedProcedure.input(z.object({ assignmentId: z.number(), notesUrl: z.string().url(), youtubeUrl: z.string().url().optional() })).mutation(async ({ ctx, input }) => { requireRole(ctx.user, ["Master Admin", "Admin", "Teacher / Operator"]); const db = await getDb(); if (db) await db.insert(notes).values({ assignmentId: input.assignmentId, notesUrl: input.notesUrl, youtubeUrl: input.youtubeUrl, uploadStatus: "uploaded", uploadedBy: ctx.user?.id, uploadedAt: new Date() }); await recordAudit(ctx, "Uploaded online notes", "lecture assignment", String(input.assignmentId), JSON.stringify({ notesUrl: input.notesUrl })); return { ...input, uploadStatus: "uploaded" as const, persisted: Boolean(db) }; }),
    recordClassDuration: protectedProcedure.input(z.object({ assignmentId: z.number(), actualStart: z.string(), actualEnd: z.string() })).mutation(async ({ ctx, input }) => { requireRole(ctx.user, ["Master Admin", "Admin", "Teacher / Operator"]); const start = new Date(input.actualStart); const end = new Date(input.actualEnd); const actualDurationMinutes = Math.max(0, Math.round((end.getTime() - start.getTime()) / 60000)); const db = await getDb(); if (db) await db.update(lectureAssignments).set({ actualStart: start, actualEnd: end, actualDurationMinutes }).where(eq(lectureAssignments.id, input.assignmentId)); await recordAudit(ctx, "Recorded class duration", "lecture assignment", String(input.assignmentId), JSON.stringify({ actualDurationMinutes })); return { actualDurationMinutes, persisted: Boolean(db) }; }),
  }),
});
export type AppRouter = typeof appRouter;
