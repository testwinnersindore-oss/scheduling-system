import { describe, expect, it } from "vitest";
import { isValidMasterAdminPassword } from "./masterAdminAuth";

describe("Master Admin password verification", () => {
  it("accepts the exact configured password", () => {
    expect(isValidMasterAdminPassword("correct-secret", "correct-secret")).toBe(true);
  });

  it("rejects incorrect, empty, and length-mismatched passwords", () => {
    expect(isValidMasterAdminPassword("wrong-secret", "correct-secret")).toBe(false);
    expect(isValidMasterAdminPassword("", "correct-secret")).toBe(false);
    expect(isValidMasterAdminPassword("correct-secret", "")).toBe(false);
    expect(isValidMasterAdminPassword("short", "longer-secret")).toBe(false);
  });
});
