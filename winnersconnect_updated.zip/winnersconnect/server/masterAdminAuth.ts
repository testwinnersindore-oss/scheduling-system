import { createHmac, timingSafeEqual } from "node:crypto";

export const MASTER_ADMIN_COOKIE = "winners_master_admin";
const UNLOCK_TTL_MS = 8 * 60 * 60 * 1000;

function signingSecret() {
  return process.env.MANUS_JWT_SECRET || process.env.MANUS_PROJECT_ID || "winners-connect-master-admin";
}

export function isValidMasterAdminPassword(password: string, expected: string): boolean {
  if (!expected) return false;
  const supplied = Buffer.from(password, "utf8");
  const configured = Buffer.from(expected, "utf8");
  return supplied.length === configured.length && timingSafeEqual(supplied, configured);
}

export function createMasterAdminUnlockToken(now = Date.now()): string {
  const payload = String(now);
  const signature = createHmac("sha256", signingSecret()).update(payload).digest("base64url");
  return `${payload}.${signature}`;
}

export function isValidMasterAdminUnlockToken(token: string | undefined, now = Date.now()): boolean {
  if (!token) return false;
  const [payload, suppliedSignature] = token.split(".");
  const timestamp = Number(payload);
  if (!payload || !suppliedSignature || !Number.isFinite(timestamp) || now - timestamp < 0 || now - timestamp > UNLOCK_TTL_MS) return false;
  const expectedSignature = createHmac("sha256", signingSecret()).update(payload).digest("base64url");
  const supplied = Buffer.from(suppliedSignature);
  const expected = Buffer.from(expectedSignature);
  return supplied.length === expected.length && timingSafeEqual(supplied, expected);
}
