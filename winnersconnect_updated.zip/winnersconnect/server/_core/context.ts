import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { parse } from "cookie";
import { sdk } from "./sdk";
import { isValidMasterAdminUnlockToken, MASTER_ADMIN_COOKIE } from "../masterAdminAuth";
import { getDb } from "../db";
import { users } from "../../drizzle/schema";
import { eq } from "drizzle-orm";
import { DASHBOARD_USER_COOKIE, getDashboardUserId } from "../userAuth";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
};

const masterAdminSession: User = {
  id: 0,
  openId: "master-admin-password",
  name: "Master Admin",
  email: null,
  loginId: null,
  passwordHash: null,
  loginMethod: "master-password",
  role: "admin",
  appRole: "Master Admin",
  createdAt: new Date(0),
  updatedAt: new Date(0),
  lastSignedIn: new Date(),
};

export async function createContext(opts: CreateExpressContextOptions): Promise<TrpcContext> {
  let user: User | null = null;
  try { user = await sdk.authenticateRequest(opts.req); } catch { user = null; }
  if (!user) {
    const token = parse(opts.req.headers.cookie || "")[MASTER_ADMIN_COOKIE];
    if (isValidMasterAdminUnlockToken(token)) user = masterAdminSession;
  }
  if (!user) {
    const userId = getDashboardUserId(parse(opts.req.headers.cookie || "")[DASHBOARD_USER_COOKIE]);
    if (userId) {
      const db = await getDb();
      if (db) user = (await db.select().from(users).where(eq(users.id, userId)).limit(1))[0] ?? null;
    }
  }
  return { req: opts.req, res: opts.res, user };
}
