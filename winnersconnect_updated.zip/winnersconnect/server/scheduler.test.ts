import { describe, expect, it } from "vitest";
import { generateScheduleRows, validateGeneratedRows } from "./scheduler";

const base = {
  faculty: [
    { id: 1, name: "Asha Sharma", subject: "Physics", mode: "offline" as const, availability: "08:00–20:00", maxLectures: 8 },
    { id: 2, name: "Ravi Jain", subject: "Chemistry", mode: "online" as const, availability: "08:00–20:00", maxLectures: 8 },
  ],
  courses: [
    { id: 10, code: "PHY-01", name: "Physics Core", subject: "Physics", mode: "offline" as const },
    { id: 11, code: "CHE-01", name: "Chemistry Core", subject: "Chemistry", mode: "online" as const },
  ],
  mappings: [
    { facultyId: 1, courseId: 10, allowed: 1, priority: "primary" as const },
    { facultyId: 2, courseId: 11, allowed: 1, priority: "primary" as const },
  ],
  resources: [
    { code: "HALL-01", name: "Hall 01", type: "hall" as const, status: "available" as const },
    { code: "STUDIO-01", name: "Studio 01", type: "studio" as const, status: "available" as const },
  ],
};

describe("schedule generation", () => {
  it("creates persisted-ready rows instead of returning a no-op", () => {
    const result = generateScheduleRows({ date: "2026-10-15", ...base });
    expect(result.rows).toHaveLength(2);
    expect(result.rows.map(row => row.scheduleDate)).toEqual(["2026-10-15", "2026-10-15"]);
    expect(result.rows[0]).toMatchObject({ startTime: "08:00", endTime: "09:15", resourceType: "hall", facultyId: 1 });
    expect(result.rows[1]).toMatchObject({ resourceType: "studio", mode: "online", facultyId: 2 });
  });

  it("does not schedule absent mapped faculty and reports the skipped course", () => {
    const result = generateScheduleRows({ ...base, date: "2026-10-15", attendance: [{ facultyId: 1, status: "absent" }] });
    expect(result.rows).toHaveLength(1);
    expect(result.rows[0].facultyId).toBe(2);
    expect(result.warnings.some(warning => warning.includes("could not be scheduled"))).toBe(true);
  });

  it("assigns an offline absent-faculty class to a free same-subject replacement", () => {
    const result = generateScheduleRows({
      ...base,
      faculty: [...base.faculty, { id: 3, name: "Neha Physics", subject: "Physics", mode: "offline" as const, availability: "08:00–20:00", maxLectures: 8 }],
      courses: [base.courses[0]],
      mappings: base.mappings.filter((mapping) => mapping.courseId === 10),
      date: "2026-10-15",
      attendance: [{ facultyId: 1, status: "absent" }],
    });
    expect(result.rows[0]).toMatchObject({ facultyId: 3, status: "replacement" });
    expect(result.rows[0]?.notes).toContain("same-course coverage");
  });

  it("defers an online lecture to the next day when its mapped faculty is absent", () => {
    const result = generateScheduleRows({ ...base, courses: [base.courses[1]], date: "2026-10-15", attendance: [{ facultyId: 2, status: "absent" }] });
    expect(result.rows).toHaveLength(0);
    expect(result.deferredOnlineCourses.map((course) => course.id)).toEqual([11]);
    expect(result.warnings.some((warning) => warning.includes("deferred to the next day"))).toBe(true);
  });

  it("never assigns more than eight lectures to one faculty and inserts a rest window", () => {
    const courses = Array.from({ length: 10 }, (_, index) => ({ id: 100 + index, code: `PHY-${index}`, name: `Physics ${index}`, subject: "Physics", mode: "offline" as const }));
    const result = generateScheduleRows({
      date: "2026-10-15",
      faculty: [base.faculty[0]],
      courses,
      mappings: [],
      resources: [base.resources[0]],
    });
    expect(result.rows.length).toBeLessThanOrEqual(8);
    expect(result.rows.filter((row) => row.facultyId === 1).length).toBeLessThanOrEqual(8);
    expect(result.rows.length).toBeLessThan(10);
  });

  it("keeps different dates isolated", () => {
    const first = generateScheduleRows({ ...base, date: "2026-10-03" });
    const second = generateScheduleRows({ ...base, date: "2026-10-15" });
    expect(first.rows.every(row => row.scheduleDate === "2026-10-03")).toBe(true);
    expect(second.rows.every(row => row.scheduleDate === "2026-10-15")).toBe(true);
  });

  it("allows lunch-time scheduling while flagging invalid resources, hours, and buffers", () => {
    const warnings = validateGeneratedRows([
      { facultyId: 1, startTime: "12:30", endTime: "14:00", mode: "offline", resourceType: "studio", durationMinutes: 90 },
      { facultyId: 2, startTime: "07:30", endTime: "08:30", mode: "online", resourceType: "hall", durationMinutes: 60 },
      { facultyId: 1, startTime: "14:05", endTime: "15:00", mode: "offline", resourceType: "hall", durationMinutes: 55 },
    ]);
    expect(warnings.some(warning => warning.includes("lunch"))).toBe(false);
    expect(warnings.some(warning => warning.includes("setup/recovery buffer"))).toBe(true);
    expect(warnings.some(warning => warning.includes("working hours"))).toBe(true);
    expect(warnings.some(warning => warning.includes("Online class"))).toBe(true);
    expect(warnings.some(warning => warning.includes("Offline class"))).toBe(true);
  });
});
