export type SchedulerFaculty = {
  id: number;
  name: string;
  subject: string;
  mode: "online" | "offline" | "hybrid";
  availability: string;
  maxLectures: number;
  active?: number;
};

export type SchedulerCourse = {
  id: number;
  code: string;
  name: string;
  subject: string;
  mode: "online" | "offline" | "hybrid";
  active?: number;
};

export type SchedulerResource = {
  code: string;
  name: string;
  type: "hall" | "studio" | "online_room";
  status: "available" | "live" | "maintenance";
  availabilityFrom?: string | null;
  availabilityTo?: string | null;
};

export type SchedulerMapping = { facultyId: number; courseId: number; allowed: number; priority: "primary" | "backup" | "none" };
export type SchedulerAttendance = { facultyId: number; status: "present" | "absent" | "half-day" | "pending"; fromTime?: string | null; toTime?: string | null };

export type GeneratedScheduleRow = {
  scheduleDate: string;
  slotNumber: number;
  startTime: string;
  endTime: string;
  facultyId: number;
  facultyName: string;
  courseIds: string;
  courseNames: string;
  lectureTitle: string;
  subject: string;
  mode: "online" | "offline" | "hybrid";
  platform: "youtube" | "app" | "offline";
  resourceCode: string | null;
  resourceType: "hall" | "studio" | "online_room" | null;
  operatorName: string | null;
  pdfUploaded: number;
  pdfReceived: number;
  notes: string | null;
  status: "ready" | "warning" | "replacement" | "done" | "cancelled";
  actualInTime: string | null;
  actualOutTime: string | null;
  actualDurationMinutes: number | null;
  reviewComplete: number;
  setupBufferMinutes: number;
  isCarryForward: number;
  carryForwardSourceDate: string | null;
  timeAdjustmentMinutes: number;
};

export const DEFAULT_RULES = {
  workStart: "08:00",
  workEnd: "20:00",
  durationMinutes: 75,
  maxLectures: 8,
  setupBufferMinutes: 10,
  restIntervalMinutes: 180,
  restDurationMinutes: 30,
};

export const timeToMinutes = (value: string) => {
  const match = /^(\d{2}):(\d{2})$/.exec(value);
  if (!match) return Number.NaN;
  const hours = Number(match[1]);
  const minutes = Number(match[2]);
  if (hours > 23 || minutes > 59) return Number.NaN;
  return hours * 60 + minutes;
};

const formatTime = (minutes: number) => `${String(Math.floor(minutes / 60)).padStart(2, "0")}:${String(minutes % 60).padStart(2, "0")}`;
const overlaps = (start: number, end: number, otherStart: number, otherEnd: number) => start < otherEnd && end > otherStart;
const parseWindow = (value: string | null | undefined, fallback: string) => timeToMinutes(value || fallback);

export function shiftTime(value: string, adjustmentMinutes: number) {
  return formatTime(timeToMinutes(value) + adjustmentMinutes);
}

export function adjustGeneratedRows(rows: GeneratedScheduleRow[], targetDate: string, sourceDate: string, adjustmentMinutes = 0): GeneratedScheduleRow[] {
  return rows.map((row) => ({
    ...row,
    scheduleDate: targetDate,
    startTime: shiftTime(row.startTime, adjustmentMinutes),
    endTime: shiftTime(row.endTime, adjustmentMinutes),
    notes: `Carried forward from ${sourceDate}${adjustmentMinutes ? ` · adjusted ${adjustmentMinutes > 0 ? "+" : ""}${adjustmentMinutes} minutes` : ""}`,
    isCarryForward: 1,
    carryForwardSourceDate: sourceDate,
    timeAdjustmentMinutes: adjustmentMinutes,
  }));
}

export function validateGeneratedRows(rows: Array<Pick<GeneratedScheduleRow, "startTime" | "endTime" | "mode" | "resourceType" | "facultyId"> & { durationMinutes: number }>, rules = DEFAULT_RULES) {
  const warnings: string[] = [];
  const facultyCount = new Map<number, number>();
  const facultyWindows = new Map<number, Array<[number, number]>>();
  const resourceWindows = new Map<string, Array<[number, number]>>();
  for (const row of rows) {
    const start = timeToMinutes(row.startTime);
    const end = timeToMinutes(row.endTime);
    if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) warnings.push(`Invalid time window ${row.startTime}–${row.endTime}`);
    if (start < timeToMinutes(rules.workStart) || end > timeToMinutes(rules.workEnd)) warnings.push(`Class ${row.startTime}–${row.endTime} is outside working hours`);
    const windows = facultyWindows.get(row.facultyId) ?? [];
    const bufferSide = rules.setupBufferMinutes / 2;
    if (windows.some(([existingStart, existingEnd]) => overlaps(start - bufferSide, end + bufferSide, existingStart - bufferSide, existingEnd + bufferSide))) warnings.push(`Faculty ${row.facultyId} needs a 10-minute total setup/recovery buffer (5 minutes before and after) around classes`);
    facultyWindows.set(row.facultyId, [...windows, [start, end]]);
    if (row.mode === "online" && !["studio", "online_room"].includes(row.resourceType ?? "")) warnings.push("Online class requires a studio or online room");
    if (row.mode === "offline" && row.resourceType !== "hall") warnings.push("Offline class requires a hall");
    facultyCount.set(row.facultyId, (facultyCount.get(row.facultyId) ?? 0) + 1);
  }
  resourceWindows.forEach(() => undefined);
  facultyCount.forEach((count, facultyId) => { if (count > rules.maxLectures) warnings.push(`Faculty ${facultyId} exceeds ${rules.maxLectures} lectures`); });
  return warnings;
}

export function generateScheduleRows(input: {
  date: string;
  faculty: SchedulerFaculty[];
  courses: SchedulerCourse[];
  resources: SchedulerResource[];
  mappings: SchedulerMapping[];
  attendance?: SchedulerAttendance[];
  rules?: typeof DEFAULT_RULES;
}): { rows: GeneratedScheduleRow[]; warnings: string[]; deferredOnlineCourses: SchedulerCourse[] } {
  const rules = input.rules ?? DEFAULT_RULES;
  const activeFaculty = input.faculty.filter((person) => person.active !== 0);
  const activeCourses = input.courses.filter((course) => course.active !== 0);
  const attendance = new Map((input.attendance ?? []).map((item) => [item.facultyId, item]));
  const available = input.resources.filter((resource) => resource.status !== "maintenance");
  const rows: GeneratedScheduleRow[] = [];
  const assignedCount = new Map<number, number>();
  const assignedWindows = new Map<number, Array<[number, number]>>();
  const deferredOnlineCourses: SchedulerCourse[] = [];
  const warnings: string[] = [];
  let cursor = timeToMinutes(rules.workStart);
  let slotNumber = 1;

  for (const course of activeCourses) {
    const end = cursor + rules.durationMinutes;
    if (end > timeToMinutes(rules.workEnd)) break;
    const mappedIds = input.mappings.filter((mapping) => mapping.courseId === course.id && mapping.allowed !== 0).sort((a, b) => (a.priority === "primary" ? -1 : b.priority === "primary" ? 1 : 0)).map((mapping) => mapping.facultyId);
    const absentMappedIds = mappedIds.filter((facultyId) => attendance.get(facultyId)?.status === "absent");
    if (course.mode === "online" && absentMappedIds.length > 0) {
      deferredOnlineCourses.push(course);
      warnings.push(`Online course ${course.code} deferred to the next day because its mapped faculty is absent`);
      continue;
    }
    const mappedPresentIds = mappedIds.filter((facultyId) => attendance.get(facultyId)?.status !== "absent");
    const useSubjectFallback = absentMappedIds.length > 0 && mappedPresentIds.length === 0;
    const candidates = activeFaculty
      .filter((person) => useSubjectFallback ? person.subject.toLowerCase() === course.subject.toLowerCase() : mappedIds.length === 0 || mappedIds.includes(person.id))
      .filter((person) => (assignedCount.get(person.id) ?? 0) < Math.min(person.maxLectures, rules.maxLectures))
      .filter((person) => {
        const attendanceRow = attendance.get(person.id);
        if (attendanceRow?.status === "absent") return false;
        const from = parseWindow(attendanceRow?.fromTime, rules.workStart);
        const to = parseWindow(attendanceRow?.toTime, rules.workEnd);
        return cursor >= from && end <= to;
      })
      .filter((person) => {
        const windows = assignedWindows.get(person.id) ?? [];
        if (!windows.length) return true;
        const last = windows[windows.length - 1];
        const gap = cursor - last[1];
        if (gap >= rules.restDurationMinutes) return true;
        const blockStart = windows.reduce((start, window, index) => {
          if (index === 0) return window[0];
          const previous = windows[index - 1];
          return window[0] - previous[1] >= rules.restDurationMinutes ? window[0] : start;
        }, windows[0][0]);
        return end - blockStart <= rules.restIntervalMinutes;
      })
      .sort((a, b) => {
        const aMapped = mappedIds.includes(a.id) ? 0 : 1;
        const bMapped = mappedIds.includes(b.id) ? 0 : 1;
        return aMapped - bMapped || (assignedCount.get(a.id) ?? 0) - (assignedCount.get(b.id) ?? 0);
      });
    const person = candidates[0];
    if (!person) {
      if (course.mode === "online") {
        deferredOnlineCourses.push(course);
        warnings.push(`Online course ${course.code} deferred to the next day because no eligible faculty is free`);
      } else {
        warnings.push(`Course ${course.code} needs a same-course replacement faculty who is free at ${formatTime(cursor)}`);
      }
      cursor += rules.durationMinutes + rules.setupBufferMinutes;
      continue;
    }
    const attendanceRow = attendance.get(person.id);
    if (attendanceRow?.status === "half-day" && end > parseWindow(attendanceRow.toTime, "13:00")) { cursor += rules.durationMinutes + rules.setupBufferMinutes; continue; }
    const mode = course.mode === "hybrid" ? "offline" : course.mode;
    const requiredTypes = mode === "online" ? ["studio", "online_room"] : ["hall"];
    const resource = available.find((item) => requiredTypes.includes(item.type) && cursor >= parseWindow(item.availabilityFrom, rules.workStart) && end <= parseWindow(item.availabilityTo, rules.workEnd));
    const platform = mode === "online" ? "app" : "offline";
    const isReplacement = absentMappedIds.length > 0 || (mappedIds.length > 0 && !mappedIds.includes(person.id));
    rows.push({
      scheduleDate: input.date, slotNumber, startTime: formatTime(cursor), endTime: formatTime(end), facultyId: person.id, facultyName: person.name,
      courseIds: String(course.id), courseNames: course.name, lectureTitle: `${course.name} lecture`, subject: person.subject || course.subject,
      mode, platform, resourceCode: resource?.code ?? null, resourceType: resource?.type ?? null, operatorName: null,
      pdfUploaded: 0, pdfReceived: 0, notes: isReplacement ? `Replacement for absent faculty · same-course coverage · ${rules.restIntervalMinutes / 60}-hour rest rule applied` : null, status: resource ? (isReplacement ? "replacement" : "ready") : "warning", actualInTime: null, actualOutTime: null,
      actualDurationMinutes: null, reviewComplete: 0, setupBufferMinutes: rules.setupBufferMinutes, isCarryForward: 0, carryForwardSourceDate: null, timeAdjustmentMinutes: 0,
    });
    assignedCount.set(person.id, (assignedCount.get(person.id) ?? 0) + 1);
    assignedWindows.set(person.id, [...(assignedWindows.get(person.id) ?? []), [cursor, end]]);
    slotNumber += 1;
    cursor = end + rules.setupBufferMinutes;
  }

  warnings.push(...validateGeneratedRows(rows.map((row) => ({ ...row, durationMinutes: rules.durationMinutes })), rules));
  if (rows.length < activeCourses.length) warnings.push(`${activeCourses.length - rows.length} course(s) could not be scheduled with the available faculty/resources`);
  return { rows, warnings, deferredOnlineCourses };
}
