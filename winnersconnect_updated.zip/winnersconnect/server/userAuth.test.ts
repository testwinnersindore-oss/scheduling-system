import { describe, expect, it } from "vitest";
import { createDashboardUserToken, getDashboardUserId, hashDashboardPassword, verifyDashboardPassword } from "./userAuth";

describe("dashboard user authentication", () => {
  it("hashes passwords without storing or accepting plaintext", () => {
    const encoded = hashDashboardPassword("correct-horse-battery");
    expect(encoded).not.toContain("correct-horse-battery");
    expect(verifyDashboardPassword("correct-horse-battery", encoded)).toBe(true);
    expect(verifyDashboardPassword("wrong-password", encoded)).toBe(false);
  });

  it("accepts a signed token and rejects tampered or invalid tokens", () => {
    const token = createDashboardUserToken(42);
    expect(getDashboardUserId(token)).toBe(42);
    expect(getDashboardUserId(`${token}x`)).toBeNull();
    expect(getDashboardUserId("not-a-token")).toBeNull();
  });
});
