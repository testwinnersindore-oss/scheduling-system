ALTER TABLE `scheduleEntries` MODIFY COLUMN `status` enum('ready','warning','replacement','done','cancelled') NOT NULL DEFAULT 'ready';
--> statement-breakpoint
ALTER TABLE `scheduleEntries` ADD `setupBufferMinutes` int DEFAULT 10 NOT NULL;
--> statement-breakpoint
ALTER TABLE `scheduleEntries` ADD `isCarryForward` int DEFAULT 0 NOT NULL;
--> statement-breakpoint
ALTER TABLE `scheduleEntries` ADD `carryForwardSourceDate` varchar(10);
--> statement-breakpoint
ALTER TABLE `scheduleEntries` ADD `timeAdjustmentMinutes` int DEFAULT 0 NOT NULL;
--> statement-breakpoint
ALTER TABLE `resources` ADD `buildingGroup` varchar(120) DEFAULT 'Main campus' NOT NULL;
--> statement-breakpoint
ALTER TABLE `resources` ADD `availabilityFrom` varchar(8) DEFAULT '08:00' NOT NULL;
--> statement-breakpoint
ALTER TABLE `resources` ADD `availabilityTo` varchar(8) DEFAULT '20:00' NOT NULL;
