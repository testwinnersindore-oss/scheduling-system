import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginId: varchar("loginId", { length: 120 }).unique(),
  passwordHash: text("passwordHash"),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  appRole: mysqlEnum("appRole", ["Master Admin", "Admin", "Teacher / Operator", "Analysis Dashboard", "Live Display"]).default("Teacher / Operator").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const faculties = mysqlTable("faculties", {
  id: int("id").autoincrement().primaryKey(),
  employeeCode: varchar("employeeCode", { length: 32 }).notNull().unique(),
  name: varchar("name", { length: 160 }).notNull(),
  initials: varchar("initials", { length: 8 }).notNull(),
  primarySubject: varchar("primarySubject", { length: 120 }).notNull(),
  defaultMode: mysqlEnum("defaultMode", ["online", "offline", "hybrid"]).notNull(),
  availability: varchar("availability", { length: 120 }).notNull().default("08:00–20:00"),
  replacementEligible: int("replacementEligible").notNull().default(0),
  maxLectures: int("maxLectures").notNull().default(8),
  notes: text("notes"),
  active: int("active").notNull().default(1),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const centres = mysqlTable("centres", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  type: mysqlEnum("type", ["offline", "online"]).notNull(),
  status: varchar("status", { length: 40 }).notNull().default("operational"),
});

export const halls = mysqlTable("halls", {
  id: int("id").autoincrement().primaryKey(),
  centreId: int("centreId").notNull(),
  name: varchar("name", { length: 80 }).notNull(),
  capacity: int("capacity").notNull().default(60),
  active: int("active").notNull().default(1),
});

export const operators = mysqlTable("operators", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  phone: varchar("phone", { length: 32 }),
  active: int("active").notNull().default(1),
});

export const courses = mysqlTable("courses", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 32 }).notNull().unique(),
  name: varchar("name", { length: 180 }).notNull(),
  studentCount: int("studentCount").notNull().default(0),
  subject: varchar("subject", { length: 160 }).notNull().default("General"),
  branch: varchar("branch", { length: 120 }).notNull().default("Indore"),
  mode: mysqlEnum("mode", ["online", "offline", "hybrid"]).notNull().default("offline"),
  status: mysqlEnum("status", ["active", "draft", "archived"]).notNull().default("active"),
  notes: text("notes"),
  active: int("active").notNull().default(1),
});

export const lectures = mysqlTable("lectures", {
  id: int("id").autoincrement().primaryKey(),
  courseId: int("courseId").notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  subject: varchar("subject", { length: 120 }).notNull(),
  facultyId: int("facultyId").notNull(),
  mode: mysqlEnum("mode", ["online", "offline"]).notNull(),
  durationMinutes: int("durationMinutes").notNull().default(75),
  active: int("active").notNull().default(1),
});

export const attendance = mysqlTable("attendance", {
  id: int("id").autoincrement().primaryKey(),
  facultyId: int("facultyId").notNull(),
  attendanceDate: varchar("attendanceDate", { length: 10 }).notNull(),
  status: mysqlEnum("status", ["present", "absent", "pending"]).notNull(),
  markedBy: int("markedBy"),
  markedAt: timestamp("markedAt").defaultNow().notNull(),
  fromTime: varchar("fromTime", { length: 8 }).default("08:00"),
  toTime: varchar("toTime", { length: 8 }).default("20:00"),
  replacementMode: mysqlEnum("replacementMode", ["not_required", "required", "assigned"]).default("not_required").notNull(),
  notes: text("notes"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const scheduleSlots = mysqlTable("scheduleSlots", {
  id: int("id").autoincrement().primaryKey(),
  scheduleDate: varchar("scheduleDate", { length: 10 }).notNull(),
  slotNumber: int("slotNumber").notNull(),
  startTime: varchar("startTime", { length: 8 }).notNull(),
  endTime: varchar("endTime", { length: 8 }).notNull(),
  isLunchLock: int("isLunchLock").notNull().default(0),
  courseId: int("courseId"),
  resourceCode: varchar("resourceCode", { length: 64 }),
  resourceType: mysqlEnum("resourceType", ["hall", "studio", "online_room"]),
  onlinePdfUpdated: int("onlinePdfUpdated").notNull().default(0),
  durationMinutes: int("durationMinutes").notNull().default(75),
  operatorId: int("operatorId"),
  actualStart: timestamp("actualStart"),
  actualEnd: timestamp("actualEnd"),
  actualDurationMinutes: int("actualDurationMinutes"),
});

export const lectureAssignments = mysqlTable("lectureAssignments", {
  id: int("id").autoincrement().primaryKey(),
  slotId: int("slotId").notNull(),
  lectureId: int("lectureId").notNull(),
  facultyId: int("facultyId").notNull(),
  substituteForFacultyId: int("substituteForFacultyId"),
  centreId: int("centreId"),
  hallId: int("hallId"),
  onlineLocation: varchar("onlineLocation", { length: 240 }),
  operatorId: int("operatorId"),
  status: mysqlEnum("status", ["auto", "manual", "live", "complete"]).notNull().default("auto"),
  notesRequired: int("notesRequired").notNull().default(0),
  originalFacultyId: int("originalFacultyId"),
  durationMinutes: int("durationMinutes").notNull().default(75),
  actualStart: timestamp("actualStart"),
  actualEnd: timestamp("actualEnd"),
  actualDurationMinutes: int("actualDurationMinutes"),
});

export const notes = mysqlTable("notes", {
  id: int("id").autoincrement().primaryKey(),
  assignmentId: int("assignmentId").notNull(),
  youtubeUrl: varchar("youtubeUrl", { length: 500 }),
  notesUrl: varchar("notesUrl", { length: 500 }),
  uploadStatus: mysqlEnum("uploadStatus", ["missing", "uploaded"]).notNull().default("missing"),
  uploadedBy: int("uploadedBy"),
  uploadedAt: timestamp("uploadedAt"),
});

export const auditLogs = mysqlTable("auditLogs", {
  id: int("id").autoincrement().primaryKey(),
  actorUserId: int("actorUserId"),
  actorName: varchar("actorName", { length: 160 }).notNull(),
  action: varchar("action", { length: 120 }).notNull(),
  entity: varchar("entity", { length: 120 }).notNull(),
  entityId: varchar("entityId", { length: 80 }),
  metadata: text("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const resources = mysqlTable("resources", {
  id: int("id").autoincrement().primaryKey(),
  resourceCode: varchar("resourceCode", { length: 64 }).notNull().unique(),
  resourceName: varchar("resourceName", { length: 160 }).notNull(),
  type: mysqlEnum("type", ["hall", "studio", "online_room"]).notNull(),
  buildingGroup: varchar("buildingGroup", { length: 120 }).notNull().default("Main campus"),
  availabilityFrom: varchar("availabilityFrom", { length: 8 }).notNull().default("08:00"),
  availabilityTo: varchar("availabilityTo", { length: 8 }).notNull().default("20:00"),
  status: mysqlEnum("status", ["available", "live", "maintenance"]).notNull().default("available"),
  notes: text("notes"),
});
export const facultyCourseMaps = mysqlTable("facultyCourseMaps", {
  id: int("id").autoincrement().primaryKey(),
  facultyId: int("facultyId").notNull(),
  courseId: int("courseId").notNull(),
  allowed: int("allowed").notNull().default(1),
  priority: mysqlEnum("priority", ["primary", "backup", "none"]).notNull().default("none"),
  notes: text("notes"),
});
export const replacementLogs = mysqlTable("replacementLogs", {
  id: int("id").autoincrement().primaryKey(),
  replacementDate: varchar("replacementDate", { length: 10 }).notNull(),
  startTime: varchar("startTime", { length: 8 }).notNull(),
  endTime: varchar("endTime", { length: 8 }).notNull(),
  originalFacultyId: int("originalFacultyId").notNull(),
  replacementFacultyId: int("replacementFacultyId"),
  courseId: int("courseId").notNull(),
  subject: varchar("subject", { length: 120 }).notNull(),
  mode: mysqlEnum("mode", ["online", "offline"]).notNull(),
  resourceCode: varchar("resourceCode", { length: 64 }),
  reason: text("reason").notNull(),
  status: mysqlEnum("status", ["assigned", "open", "declined"]).notNull().default("open"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export const ruleCatalog = mysqlTable("ruleCatalog", {
  id: int("id").autoincrement().primaryKey(),
  rule: varchar("rule", { length: 64 }).notNull().unique(),
  value: varchar("value", { length: 64 }).notNull(),
  description: text("description").notNull(),
  active: int("active").notNull().default(1),
});
export const settings = mysqlTable("settings", {
  id: int("id").autoincrement().primaryKey(),
  operatingStart: varchar("operatingStart", { length: 8 }).notNull().default("08:00"),
  operatingEnd: varchar("operatingEnd", { length: 8 }).notNull().default("20:00"),
  dailyClassCapacity: int("dailyClassCapacity").notNull().default(8),
  lunchStart: varchar("lunchStart", { length: 8 }).notNull().default("13:00"),
  lunchEnd: varchar("lunchEnd", { length: 8 }).notNull().default("13:40"),
  sheetMappingVersion: varchar("sheetMappingVersion", { length: 32 }).notNull().default("v1"),
});
export const scheduleEntries = mysqlTable("scheduleEntries", {
  id: int("id").autoincrement().primaryKey(),
  scheduleDate: varchar("scheduleDate", { length: 10 }).notNull(),
  slotNumber: int("slotNumber").notNull(),
  startTime: varchar("startTime", { length: 8 }).notNull(),
  endTime: varchar("endTime", { length: 8 }).notNull(),
  facultyId: int("facultyId"),
  facultyName: varchar("facultyName", { length: 160 }).notNull(),
  courseIds: text("courseIds").notNull(),
  courseNames: text("courseNames").notNull(),
  lectureTitle: varchar("lectureTitle", { length: 180 }).notNull(),
  subject: varchar("subject", { length: 160 }).notNull(),
  mode: mysqlEnum("mode", ["online", "offline", "hybrid"]).notNull(),
  platform: mysqlEnum("platform", ["youtube", "app", "offline"]).notNull().default("offline"),
  resourceCode: varchar("resourceCode", { length: 64 }),
  resourceType: mysqlEnum("resourceType", ["hall", "studio", "online_room"]),
  operatorName: varchar("operatorName", { length: 160 }),
  pdfUploaded: int("pdfUploaded").notNull().default(0),
  pdfReceived: int("pdfReceived").notNull().default(0),
  notes: text("notes"),
  status: mysqlEnum("status", ["ready", "warning", "replacement", "done", "cancelled"]).notNull().default("ready"),
  actualInTime: varchar("actualInTime", { length: 8 }),
  actualOutTime: varchar("actualOutTime", { length: 8 }),
  actualDurationMinutes: int("actualDurationMinutes"),
  reviewComplete: int("reviewComplete").notNull().default(0),
  setupBufferMinutes: int("setupBufferMinutes").notNull().default(10),
  isCarryForward: int("isCarryForward").notNull().default(0),
  carryForwardSourceDate: varchar("carryForwardSourceDate", { length: 10 }),
  timeAdjustmentMinutes: int("timeAdjustmentMinutes").notNull().default(0),
  isDeleted: int("isDeleted").notNull().default(0),
  deletedAt: timestamp("deletedAt"),
  deletedBy: int("deletedBy"),
  createdBy: int("createdBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
