CREATE TABLE `facultyCourseMaps` (
	`id` int AUTO_INCREMENT NOT NULL,
	`facultyId` int NOT NULL,
	`courseId` int NOT NULL,
	`allowed` int NOT NULL DEFAULT 1,
	`priority` enum('primary','backup','none') NOT NULL DEFAULT 'none',
	`notes` text,
	CONSTRAINT `facultyCourseMaps_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `replacementLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`replacementDate` varchar(10) NOT NULL,
	`startTime` varchar(8) NOT NULL,
	`endTime` varchar(8) NOT NULL,
	`originalFacultyId` int NOT NULL,
	`replacementFacultyId` int,
	`courseId` int NOT NULL,
	`subject` varchar(120) NOT NULL,
	`mode` enum('online','offline') NOT NULL,
	`resourceCode` varchar(64),
	`reason` text NOT NULL,
	`status` enum('assigned','open','declined') NOT NULL DEFAULT 'open',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `replacementLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `resources` (
	`id` int AUTO_INCREMENT NOT NULL,
	`resourceCode` varchar(64) NOT NULL,
	`resourceName` varchar(160) NOT NULL,
	`type` enum('hall','studio','online_room') NOT NULL,
	`status` enum('available','live','maintenance') NOT NULL DEFAULT 'available',
	`notes` text,
	CONSTRAINT `resources_id` PRIMARY KEY(`id`),
	CONSTRAINT `resources_resourceCode_unique` UNIQUE(`resourceCode`)
);
--> statement-breakpoint
CREATE TABLE `ruleCatalog` (
	`id` int AUTO_INCREMENT NOT NULL,
	`rule` varchar(64) NOT NULL,
	`value` varchar(64) NOT NULL,
	`description` text NOT NULL,
	`active` int NOT NULL DEFAULT 1,
	CONSTRAINT `ruleCatalog_id` PRIMARY KEY(`id`),
	CONSTRAINT `ruleCatalog_rule_unique` UNIQUE(`rule`)
);
--> statement-breakpoint
ALTER TABLE `attendance` ADD `fromTime` varchar(8) DEFAULT '08:00';--> statement-breakpoint
ALTER TABLE `attendance` ADD `toTime` varchar(8) DEFAULT '20:00';--> statement-breakpoint
ALTER TABLE `attendance` ADD `replacementMode` enum('not_required','required','assigned') DEFAULT 'not_required' NOT NULL;--> statement-breakpoint
ALTER TABLE `attendance` ADD `notes` text;--> statement-breakpoint
ALTER TABLE `attendance` ADD `updatedAt` timestamp DEFAULT (now()) NOT NULL ON UPDATE CURRENT_TIMESTAMP;--> statement-breakpoint
ALTER TABLE `courses` ADD `subject` varchar(160) DEFAULT 'General' NOT NULL;--> statement-breakpoint
ALTER TABLE `courses` ADD `branch` varchar(120) DEFAULT 'Indore' NOT NULL;--> statement-breakpoint
ALTER TABLE `courses` ADD `mode` enum('online','offline','hybrid') DEFAULT 'offline' NOT NULL;--> statement-breakpoint
ALTER TABLE `courses` ADD `status` enum('active','draft','archived') DEFAULT 'active' NOT NULL;--> statement-breakpoint
ALTER TABLE `courses` ADD `notes` text;--> statement-breakpoint
ALTER TABLE `faculties` ADD `replacementEligible` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `faculties` ADD `maxLectures` int DEFAULT 8 NOT NULL;--> statement-breakpoint
ALTER TABLE `faculties` ADD `notes` text;--> statement-breakpoint
ALTER TABLE `lectureAssignments` ADD `originalFacultyId` int;--> statement-breakpoint
ALTER TABLE `lectureAssignments` ADD `durationMinutes` int DEFAULT 75 NOT NULL;--> statement-breakpoint
ALTER TABLE `lectureAssignments` ADD `actualStart` timestamp;--> statement-breakpoint
ALTER TABLE `lectureAssignments` ADD `actualEnd` timestamp;--> statement-breakpoint
ALTER TABLE `lectureAssignments` ADD `actualDurationMinutes` int;--> statement-breakpoint
ALTER TABLE `scheduleSlots` ADD `courseId` int;--> statement-breakpoint
ALTER TABLE `scheduleSlots` ADD `resourceCode` varchar(64);--> statement-breakpoint
ALTER TABLE `scheduleSlots` ADD `resourceType` enum('hall','studio','online_room');--> statement-breakpoint
ALTER TABLE `scheduleSlots` ADD `onlinePdfUpdated` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `scheduleSlots` ADD `durationMinutes` int DEFAULT 75 NOT NULL;--> statement-breakpoint
ALTER TABLE `scheduleSlots` ADD `operatorId` int;--> statement-breakpoint
ALTER TABLE `scheduleSlots` ADD `actualStart` timestamp;--> statement-breakpoint
ALTER TABLE `scheduleSlots` ADD `actualEnd` timestamp;--> statement-breakpoint
ALTER TABLE `scheduleSlots` ADD `actualDurationMinutes` int;