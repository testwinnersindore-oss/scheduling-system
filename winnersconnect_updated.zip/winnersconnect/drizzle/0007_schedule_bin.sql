ALTER TABLE `scheduleEntries` ADD `isDeleted` int NOT NULL DEFAULT 0;
--> statement-breakpoint
ALTER TABLE `scheduleEntries` ADD `deletedAt` timestamp NULL;
--> statement-breakpoint
ALTER TABLE `scheduleEntries` ADD `deletedBy` int NULL;
