ALTER TABLE `users` ADD `loginId` varchar(120);
--> statement-breakpoint
ALTER TABLE `users` ADD `passwordHash` text;
--> statement-breakpoint
CREATE UNIQUE INDEX `users_loginId_unique` ON `users` (`loginId`);
