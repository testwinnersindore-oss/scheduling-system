CREATE TABLE `attendance` (
	`id` int AUTO_INCREMENT NOT NULL,
	`facultyId` int NOT NULL,
	`attendanceDate` varchar(10) NOT NULL,
	`status` enum('present','absent','pending') NOT NULL,
	`markedBy` int,
	`markedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `attendance_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `auditLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`actorUserId` int,
	`actorName` varchar(160) NOT NULL,
	`action` varchar(120) NOT NULL,
	`entity` varchar(120) NOT NULL,
	`entityId` varchar(80),
	`metadata` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `auditLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `centres` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(160) NOT NULL,
	`type` enum('offline','online') NOT NULL,
	`status` varchar(40) NOT NULL DEFAULT 'operational',
	CONSTRAINT `centres_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `courses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(32) NOT NULL,
	`name` varchar(180) NOT NULL,
	`studentCount` int NOT NULL DEFAULT 0,
	`active` int NOT NULL DEFAULT 1,
	CONSTRAINT `courses_id` PRIMARY KEY(`id`),
	CONSTRAINT `courses_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `faculties` (
	`id` int AUTO_INCREMENT NOT NULL,
	`employeeCode` varchar(32) NOT NULL,
	`name` varchar(160) NOT NULL,
	`initials` varchar(8) NOT NULL,
	`primarySubject` varchar(120) NOT NULL,
	`defaultMode` enum('online','offline','hybrid') NOT NULL,
	`availability` varchar(120) NOT NULL DEFAULT '08:00–20:00',
	`active` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `faculties_id` PRIMARY KEY(`id`),
	CONSTRAINT `faculties_employeeCode_unique` UNIQUE(`employeeCode`)
);
--> statement-breakpoint
CREATE TABLE `halls` (
	`id` int AUTO_INCREMENT NOT NULL,
	`centreId` int NOT NULL,
	`name` varchar(80) NOT NULL,
	`capacity` int NOT NULL DEFAULT 60,
	`active` int NOT NULL DEFAULT 1,
	CONSTRAINT `halls_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `lectureAssignments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slotId` int NOT NULL,
	`lectureId` int NOT NULL,
	`facultyId` int NOT NULL,
	`substituteForFacultyId` int,
	`centreId` int,
	`hallId` int,
	`onlineLocation` varchar(240),
	`operatorId` int,
	`status` enum('auto','manual','live','complete') NOT NULL DEFAULT 'auto',
	`notesRequired` int NOT NULL DEFAULT 0,
	CONSTRAINT `lectureAssignments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `lectures` (
	`id` int AUTO_INCREMENT NOT NULL,
	`courseId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`subject` varchar(120) NOT NULL,
	`facultyId` int NOT NULL,
	`mode` enum('online','offline') NOT NULL,
	`durationMinutes` int NOT NULL DEFAULT 75,
	`active` int NOT NULL DEFAULT 1,
	CONSTRAINT `lectures_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`assignmentId` int NOT NULL,
	`youtubeUrl` varchar(500),
	`notesUrl` varchar(500),
	`uploadStatus` enum('missing','uploaded') NOT NULL DEFAULT 'missing',
	`uploadedBy` int,
	`uploadedAt` timestamp,
	CONSTRAINT `notes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `operators` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(160) NOT NULL,
	`phone` varchar(32),
	`active` int NOT NULL DEFAULT 1,
	CONSTRAINT `operators_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `scheduleSlots` (
	`id` int AUTO_INCREMENT NOT NULL,
	`scheduleDate` varchar(10) NOT NULL,
	`slotNumber` int NOT NULL,
	`startTime` varchar(8) NOT NULL,
	`endTime` varchar(8) NOT NULL,
	`isLunchLock` int NOT NULL DEFAULT 0,
	CONSTRAINT `scheduleSlots_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`operatingStart` varchar(8) NOT NULL DEFAULT '08:00',
	`operatingEnd` varchar(8) NOT NULL DEFAULT '20:00',
	`dailyClassCapacity` int NOT NULL DEFAULT 8,
	`lunchStart` varchar(8) NOT NULL DEFAULT '13:00',
	`lunchEnd` varchar(8) NOT NULL DEFAULT '13:40',
	`sheetMappingVersion` varchar(32) NOT NULL DEFAULT 'v1',
	CONSTRAINT `settings_id` PRIMARY KEY(`id`)
);
