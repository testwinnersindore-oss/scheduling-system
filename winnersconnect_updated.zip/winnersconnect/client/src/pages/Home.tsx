import { useEffect, useMemo, useRef, useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import {
  Activity,
  AlertCircle,
  ArrowRight,
  BarChart3,
  Bell,
  BookOpen,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronDown,
  Clock3,
  Command,
  Database,
  Edit3,
  ExternalLink,
  FileCheck2,
  FileText,
  Filter,
  GraduationCap,
  LayoutDashboard,
  LifeBuoy,
  ListChecks,
  LockKeyhole,
  LogOut,
  Menu,
  MoreHorizontal,
  Network,
  Plus,
  Radio,
  Search,
  Save,
  Settings2,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  TimerReset,
  Trash2,
  UserCheck,
  UserCog,
  Users,
  X,
  Zap,
} from "lucide-react";
import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { exportRows } from "@/lib/export";
import SiteLoginPage, { type SiteSession } from "@/components/SiteLoginPage";
import {
  auditEntries,
  courses,
  faculty as seedFaculty,
  initialSlots,
  locations,
  quickMetrics,
  type Faculty,
  type Role,
  type Slot,
} from "@/lib/winners-data";
import { facultyCourseMaps as seedFacultyCourseMaps, masterCourses as seedMasterCourses, type MasterCourse, type FacultyCourseMap, type ResourceRecord } from "@/lib/master-data";
import MasterData from "@/pages/MasterData";
import Scheduling from "@/pages/Scheduling";

const navGroups = [
  {
    label: "Command centre",
    items: [
      { label: "Overview", path: "/", icon: LayoutDashboard },
      { label: "Schedule board", path: "/schedule", icon: CalendarDays },
      { label: "Scheduling control", path: "/scheduling", icon: Clock3 },
      { label: "Attendance", path: "/attendance", icon: UserCheck },
    ],
  },
  {
    label: "Academic master",
    items: [
      { label: "Faculty roster", path: "/faculty", icon: Users },
      { label: "Master data", path: "/master-data", icon: Database },
      { label: "Courses & lectures", path: "/courses", icon: BookOpen },
      { label: "Notes compliance", path: "/notes", icon: FileCheck2, tag: "2" },
    ],
  },
  {
    label: "Control & insight",
    items: [
      { label: "Analysis dashboard", path: "/analytics", icon: BarChart3 },
      { label: "Audit log", path: "/audit", icon: ShieldCheck },
      { label: "Settings", path: "/settings", icon: Settings2 },
    ],
  },
];

const formatDateLabel = (date: string) => new Intl.DateTimeFormat("en-IN", { weekday: "long", day: "2-digit", month: "long", year: "numeric" }).format(new Date(`${date}T00:00:00`));
const BLANK_DATA_VERSION = "blank-v1";
const purgeDemoStorage = () => {
  try {
    if (window.localStorage.getItem("winners-data-mode") === BLANK_DATA_VERSION) return;
    const demoPrefixes = ["winners-faculty", "winners-courses", "winners-faculty-course-maps", "winners-resources", "winners-slots", "winners-deleted-master", "winners-users", "winners-activity"];
    Object.keys(window.localStorage).filter((key) => demoPrefixes.some((prefix) => key === prefix || key.startsWith(`${prefix}-`))).forEach((key) => window.localStorage.removeItem(key));
    window.localStorage.setItem("winners-data-mode", BLANK_DATA_VERSION);
  } catch { /* localStorage may be unavailable */ }
};
const pageMeta: Record<string, { eyebrow: string; title: string; description: string }> = {
  "/": { eyebrow: "Date-wise command centre", title: "Good morning, command centre.", description: "Keep every class, faculty and room moving on time." },
  "/schedule": { eyebrow: "Daily operations · 8 class slots", title: "Schedule board", description: "A clean view of today’s online and offline teaching plan." },
  "/scheduling": { eyebrow: "Date-wise planning · Rule validation", title: "Scheduling control", description: "Present faculty, course, resource, operator and duration — resolved before final schedule." },
  "/attendance": { eyebrow: "Presence control · no records", title: "Attendance desk", description: "Mark presence once. Let the schedule do the rest." },
  "/faculty": { eyebrow: "Master data · Faculty records", title: "Faculty roster", description: "Every teacher, subject and availability in one source of truth." },
  "/master-data": { eyebrow: "One-time setup · Protected records", title: "Master data", description: "Maintain faculty, courses, mappings, resources and rules. Attendance and replacements stay in operations." },
  "/courses": { eyebrow: "Academic master · Courses & lectures", title: "Courses & lectures", description: "Map the right subject, faculty and lecture to every batch." },
  "/notes": { eyebrow: "Compliance queue · Online classes", title: "Notes compliance", description: "Online lectures stay complete only when notes and links are in." },
  "/analytics": { eyebrow: "Read-only insight · Today", title: "Analysis dashboard", description: "A quick read on attendance, utilization and operational health." },
  "/audit": { eyebrow: "Traceability · Every change", title: "Audit log", description: "A timestamped trail of what changed, who changed it and why." },
  "/settings": { eyebrow: "Governance · Role-based controls", title: "System settings", description: "Make the rules explicit. Keep the handoffs accountable." },
  "/live": { eyebrow: "Public-facing room display · Auto-refresh ready", title: "Live display", description: "The next class, its room and its operator — at a glance." },
};

function Wordmark({ compact = false }: { compact?: boolean }) {
  return (
    <div className={compact ? "brand-mark brand-mark--compact" : "brand-mark"} aria-label="WiNNERS Institute Indore">
      <span className="brand-w">W</span><span className="brand-i">i</span><span className="brand-nners">NNERS</span>
      {!compact && <span className="brand-sub">INSTITUTE · INDORE</span>}
    </div>
  );
}

function StatusPill({ children, tone = "neutral" }: { children: React.ReactNode; tone?: string }) {
  return <span className={`status-pill status-pill--${tone}`}>{children}</span>;
}

function MetricCard({ metric }: { metric: (typeof quickMetrics)[number] }) {
  const icons = { green: CheckCircle2, blue: Activity, red: FileText, amber: AlertCircle };
  const Icon = icons[metric.tone as keyof typeof icons];
  return (
    <article className="metric-card">
      <div className={`metric-icon metric-icon--${metric.tone}`}><Icon size={17} strokeWidth={2.2} /></div>
      <div className="metric-copy"><span>{metric.label}</span><strong>{metric.value}</strong><small>{metric.detail}</small></div>
      <MoreHorizontal size={18} className="muted-icon" />
    </article>
  );
}

function Shell({ children, path, role, setRole, selectedDate, onDateChange, onExport }: { children: React.ReactNode; path: string; role: Role; setRole: (role: Role) => void; selectedDate: string; onDateChange: (date: string) => void; onExport: () => void }) {
  const [, setLocation] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const meta = path === "/" ? { ...(pageMeta[path] ?? pageMeta["/"]), eyebrow: formatDateLabel(selectedDate) } : (pageMeta[path] ?? pageMeta["/"]);
  const go = (nextPath: string) => { setLocation(nextPath); setMobileOpen(false); };

  return (
    <div className="app-shell">
      <aside className={`app-sidebar ${mobileOpen ? "is-open" : ""}`}>
        <div className="sidebar-top"><Wordmark /><button className="mobile-close" onClick={() => setMobileOpen(false)}><X size={18} /></button></div>
        <div className="workspace-switcher"><div className="workspace-icon"><Command size={15} /></div><div><span>Workspace</span><strong>Indore operations</strong></div><ChevronDown size={14} className="workspace-chevron" /></div>
        <nav className="nav-scroll">
          {navGroups.map((group) => <div className="nav-group" key={group.label}><span className="nav-label">{group.label}</span>{group.items.map((item) => { const Icon = item.icon; const active = path === item.path; return <button key={item.path} className={`nav-item ${active ? "is-active" : ""}`} onClick={() => go(item.path)}><Icon size={17} /><span>{item.label}</span>{item.tag && <em>{item.tag}</em>}</button>; })}</div>)}
        </nav>
        <div className="sidebar-footer"><div className="sync-card"><div className="sync-card__icon"><Database size={14} /></div><div><strong>Awaiting master data</strong><span>Sheets-ready structure</span></div><span className="sync-dot" /></div><button className="master-admin-login" onClick={() => go("/master-admin")}><div className="avatar avatar--dark">MA</div><div className="profile-copy"><strong>Master Admin login</strong><span>Open protected workspace</span></div><ArrowRight size={15} /></button><div className="profile-row"><div className="avatar avatar--dark">MA</div><div className="profile-copy"><strong>Master Admin</strong><span>Winners Institute</span></div><button className="icon-button icon-button--dark" title="Account"><MoreHorizontal size={17} /></button></div></div>
      </aside>
      {mobileOpen && <div className="sidebar-scrim" onClick={() => setMobileOpen(false)} />}
      <main className="main-canvas">
        <header className="topbar"><button className="mobile-menu" onClick={() => setMobileOpen(true)}><Menu size={20} /></button><div className="breadcrumb"><span>Winners Connect</span><ArrowRight size={13} /><strong>{meta.title}</strong></div><div className="topbar-actions"><label className="date-chip"><CalendarDays size={15} /><input type="date" value={selectedDate} onChange={(event) => { onDateChange(event.target.value); toast.success(`Dashboard date changed to ${event.target.value}`); }} /><ChevronDown size={13} /></label><div className="notification-wrap"><button className="notification-button" title="Notifications" onClick={() => setNotificationsOpen((open) => !open)}><Bell size={18} /><i>0</i></button>{notificationsOpen && <div className="notification-popover"><strong>Notifications</strong><span>No pending notifications.</span></div>}</div><div className="role-selector"><ShieldCheck size={14} /><select disabled={role !== "Master Admin" && window.localStorage.getItem("winners-limited-access") !== "true"} value={role} onChange={(e) => { const next = e.target.value as Role; setRole(next); try { window.localStorage.setItem("winners-access-role", next); } catch { /* ignore */ } }} aria-label="Role selector">{(window.localStorage.getItem("winners-limited-access") === "true" ? (() => { try { return JSON.parse(window.localStorage.getItem("winners-access-roles") || "[]") as Role[]; } catch { return [role]; } })() : ["Master Admin", "Admin", "Teacher / Operator", "Analysis Dashboard", "Live Display"] as Role[]).map((item) => <option key={item}>{item}</option>)}</select><ChevronDown size={12} /></div></div></header>
        <div className="content-wrap"><div className="page-heading"><div><p className="eyebrow">{meta.eyebrow}</p><h1>{meta.title}</h1><p className="page-description">{meta.description}</p></div><div className="heading-actions"><StatusPill tone="green"><span className="live-dot" /> System operational</StatusPill><button className="outline-button" onClick={onExport}>Export view <ExternalLink size={14} /></button></div></div>{children}</div>
      </main>
    </div>
  );
}

function Overview({ slots, attendance, onGenerate, onMarkAll, onNavigate, activity, selectedDate }: { slots: Slot[]; attendance: Faculty[]; onGenerate: () => void; onMarkAll: () => void; onNavigate: (path: string) => void; activity: typeof auditEntries; selectedDate: string }) {
  const present = attendance.filter((person) => person.status === "present").length;
  return <>
    <section className="metric-grid">{quickMetrics.map((metric) => <MetricCard metric={metric} key={metric.label} />)}</section>
    <div className="dashboard-grid dashboard-grid--overview">
      <section className="panel schedule-panel"><div className="panel-heading"><div><span className="section-kicker"><Clock3 size={14} /> {formatDateLabel(selectedDate)} · RUN OF SHOW</span><h2>Classes in motion</h2></div><button className="text-button" onClick={() => onNavigate("/schedule")}>View full board <ArrowRight size={14} /></button></div><div className="schedule-list">{slots.slice(0, 5).map((slot) => <ScheduleRow key={slot.id} slot={slot} />)}</div><div className="panel-footer"><span><span className="live-dot live-dot--dark" /> {present} faculty present so far</span><button className="soft-button" onClick={onGenerate}><Sparkles size={14} /> Generate schedule</button></div></section>
      <section className="panel attention-panel"><div className="panel-heading"><div><span className="section-kicker section-kicker--red"><AlertCircle size={14} /> NEEDS ATTENTION</span><h2>Exception queue</h2></div><span className="counter">0</span></div><div className="empty-state">No exceptions yet. Warnings will appear after records are added and validated.</div><div className="attention-footer"><Clock3 size={14} /> 10-minute total setup/recovery buffer: 5 minutes before and 5 minutes after each class. Rest is protected every 3 hours.</div></section>
    </div>
    <section className="lower-grid"><div className="panel pulse-panel"><div className="panel-heading"><div><span className="section-kicker"><Activity size={14} /> OPERATIONS PULSE</span><h2>{formatDateLabel(selectedDate)} at a glance</h2></div><button className="icon-button" onClick={() => onNavigate("/master-data")} title="View master data"><Edit3 size={15} /></button></div><div className="pulse-chart"><div className="chart-y"><span>40</span><span>30</span><span>20</span><span>10</span><span>0</span></div><div className="chart-content"><div className="chart-lines"><i /><i /><i /><i /><i /></div><div className="bars">{[] .map((height, i) => <span key={i} style={{ height: `${height * 2.1}px` }} className={i > 8 ? "bar-muted" : ""} />)}</div><div className="chart-x"><span>8 AM</span><span>10 AM</span><span>12 PM</span><span>2 PM</span><span>4 PM</span><span>6 PM</span></div></div></div><div className="chart-legend"><span><i className="legend-dot legend-dot--blue" /> Present faculty</span><span><i className="legend-dot legend-dot--red" /> Classes live</span><strong>+12.4% <small>vs. last Wednesday</small></strong></div></div><div className="panel audit-panel"><div className="panel-heading"><div><span className="section-kicker"><ShieldCheck size={14} /> AUDIT TRAIL</span><h2>Recent activity</h2></div><button className="text-button" onClick={() => onNavigate("/audit")}>See all <ArrowRight size={14} /></button></div><div className="audit-list">{activity.slice(0, 5).map((entry) => <div className="audit-row" key={`${entry.time}-${entry.action}`}><div className={`audit-marker audit-marker--${entry.tone}`}><Check size={12} /></div><div className="audit-copy"><strong>{entry.action}</strong><span>{entry.actor} · {entry.entity}</span></div><time>{entry.time}</time></div>)}</div></div></section>
  </>;
}

function ScheduleRow({ slot }: { slot: Slot }) {
  if (slot.status === "lunch") return null;
  const tone = slot.status === "live" ? "red" : slot.status === "next" ? "blue" : slot.status === "done" ? "green" : "neutral";
  const courses = slot.course.split(" + ").map((item) => item.trim()).filter(Boolean);
  return <div className={`schedule-row schedule-row--${slot.status}`}><div className="schedule-time"><strong>{slot.time}</strong><span>{slot.label}</span></div><div className={`subject-block subject-block--${slot.color}`}><div className="subject-marker" /><div><strong>{slot.lecture}</strong><details><summary>{courses.length} course{courses.length === 1 ? "" : "s"} covered</summary><div className="course-detail-list">{courses.map((course) => <span key={course}>{course}{slot.subject ? ` · ${slot.subject}` : ""}</span>)}</div></details></div></div><div className="schedule-location"><strong>{slot.faculty}</strong><span>{slot.mode} · {slot.location}</span></div><div className="schedule-operator"><span>Operator</span><strong>{slot.operator}</strong></div><StatusPill tone={tone}>{slot.status === "live" ? <><span className="live-dot" /> Live now</> : slot.status === "next" ? "Next" : slot.status === "done" ? "Complete" : "Upcoming"}</StatusPill></div>;
}

function SchedulePage({ slots, onGenerate }: { slots: Slot[]; onGenerate: () => void }) {
  const [mode, setMode] = useState("All modes");
  const filtered = slots.filter((slot) => slot.status !== "lunch" && (mode === "All modes" || slot.mode === mode));
  return <><div className="toolbar-row"><div className="filter-tabs"><button className={mode === "All modes" ? "is-selected" : ""} onClick={() => setMode("All modes")}>All classes <span>{filtered.length}</span></button><button className={mode === "Online" ? "is-selected" : ""} onClick={() => setMode("Online")}>Online <span>{slots.filter((slot) => slot.mode === "Online").length}</span></button><button className={mode === "Offline" ? "is-selected" : ""} onClick={() => setMode("Offline")}>Offline <span>{slots.filter((slot) => slot.mode === "Offline").length}</span></button></div><div className="toolbar-actions"><button className="outline-button"><Filter size={14} /> Filters</button><button className="primary-button" onClick={onGenerate}><Sparkles size={15} /> Auto-generate</button></div></div><section className="panel schedule-board"><div className="board-header"><span>Slot</span><span>Lecture</span><span>Faculty / mode</span><span>Operator</span><span>Status</span></div>{filtered.map((slot) => <ScheduleRow key={slot.id} slot={slot} />)}</section><div className="rule-callout rule-callout--blue"><Clock3 size={16} /><div><strong>Faculty setup and recovery buffer is active.</strong><span>Every class keeps a 10-minute total buffer: 5 minutes before and 5 minutes after it. Rest is protected every 3 hours; lunch is not a fixed system rule.</span></div><StatusPill tone="green">10 min buffer</StatusPill></div></>;
}

function AttendancePage({ faculty, onChange, onMarkAll, onSubstitute }: { faculty: Faculty[]; onChange: (id: number, status: Faculty["status"]) => void; onMarkAll: () => void; onSubstitute: (name: string) => void }) {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("All");
  const rows = faculty.filter((person) => person.name.toLowerCase().includes(query.toLowerCase()) && (filter === "All" || person.status === filter.toLowerCase()));
  return <><div className="attendance-hero"><div className="attendance-summary"><div className="attendance-big"><strong>{faculty.filter((person) => person.status === "present").length}</strong><span>/ {faculty.length} present</span></div><div className="attendance-progress"><div style={{ width: `${(faculty.length ? faculty.filter((person) => person.status === "present").length / faculty.length : 0) * 100}%` }} /></div><small>Attendance captured at 10:32 AM · Auto-schedule is ready</small></div><button className="primary-button" onClick={onMarkAll}><CheckCircle2 size={15} /> Mark all present</button></div><div className="toolbar-row"><div className="filter-tabs"><button className={filter === "All" ? "is-selected" : ""} onClick={() => setFilter("All")}>All <span>{faculty.length}</span></button><button className={filter === "present" ? "is-selected" : ""} onClick={() => setFilter("present")}>Present <span>{faculty.filter((p) => p.status === "present").length}</span></button><button className={filter === "absent" ? "is-selected" : ""} onClick={() => setFilter("absent")}>Absent <span>{faculty.filter((p) => p.status === "absent").length}</span></button><button className={filter === "half-day" ? "is-selected" : ""} onClick={() => setFilter("half-day")}>Half-day <span>{faculty.filter((p) => p.status === "half-day").length}</span></button><button className={filter === "pending" ? "is-selected" : ""} onClick={() => setFilter("pending")}>Pending <span>{faculty.filter((p) => p.status === "pending").length}</span></button></div><label className="search-field"><Search size={15} /><input placeholder="Search faculty" value={query} onChange={(e) => setQuery(e.target.value)} /></label></div><section className="panel data-panel"><div className="data-table data-table--attendance"><div className="data-head"><span>Faculty</span><span>Subject</span><span>Availability</span><span>Sessions</span><span>Status</span><span /></div>{rows.map((person) => <div className="data-row" key={person.id}><div className="person-cell"><div className="avatar avatar--light">{person.initials}</div><div><strong>{person.name}</strong><span>{person.code}</span></div></div><span>{person.subject}</span><span className="availability"><span className={`status-dot status-dot--${person.status}`} />{person.availability}</span><span>{person.sessions} today</span><div><StatusPill tone={person.status === "present" ? "green" : person.status === "absent" ? "red" : person.status === "half-day" ? "blue" : "amber"}>{person.status === "present" ? "Present" : person.status === "absent" ? "Absent" : person.status === "half-day" ? "Half-day" : "Pending"}</StatusPill></div><div className="row-actions">{person.status === "absent" ? <button className="mini-button mini-button--primary" onClick={() => onSubstitute(person.name)}><UserCog size={13} /> Find substitute</button> : person.status !== "present" ? <><button className="mini-button mini-button--primary" onClick={() => onChange(person.id, "present")}><Check size={13} /> Mark present</button><button className="mini-button" onClick={() => onChange(person.id, "half-day")}>Half-day</button></> : person.id % 6 === 0 ? <button className="mini-button" onClick={() => onSubstitute(person.name)}>Substitute <ArrowRight size={13} /></button> : <button className="icon-button"><MoreHorizontal size={16} /></button>}</div></div>)}</div><div className="table-footer">Showing {rows.length} of {rows.length} faculty <span>·</span> <button onClick={() => toast.success("Attendance roster is already open")}>Open full roster <ArrowRight size={13} /></button></div></section></>;
}

function FacultyPage({ faculty, onEdit, canEdit }: { faculty: Faculty[]; onEdit: (person: Faculty) => void; canEdit: boolean }) {
  return <><div className="toolbar-row"><div className="filter-tabs"><button className="is-selected">All faculty <span>{faculty.length}</span></button><button>Online-first <span>0</span></button><button>Substitute pool <span>0</span></button></div><div className="toolbar-actions"><label className="search-field"><Search size={15} /><input placeholder="Search by subject or name" /></label></div></div><section className="panel data-panel"><div className="data-table"><div className="data-head"><span>Faculty</span><span>Primary subject</span><span>Default mode</span><span>Today</span><span>Availability</span><span /></div>{faculty.map((person) => <div className="data-row" key={person.id}><div className="person-cell"><div className="avatar avatar--light">{person.initials}</div><div><strong>{person.name}</strong><span>{person.code}</span></div></div><span>{person.subject}</span><StatusPill tone={person.mode === "Online" ? "blue" : person.mode === "Hybrid" ? "amber" : "slate"}>{person.mode}</StatusPill><span>{person.sessions} lectures</span><span className="availability"><span className={`status-dot status-dot--${person.status}`} />{person.availability}</span>{canEdit && <button className="icon-button" onClick={() => onEdit(person)}><Edit3 size={15} /></button>}</div>)}</div><div className="table-footer">{faculty.length} faculty records · Add records from Master Data <button onClick={() => toast.info("Google Sheets mapping is ready for a future connector")}>View data mapping <ArrowRight size={13} /></button></div></section></>;
}

function CoursesPage({ selectedDate, courses = [] }: { selectedDate: string; courses?: MasterCourse[] }) {
  const [, setLocation] = useLocation();
  const localMasterCourseData: MasterCourse[] = useMemo(() => { try { const saved = JSON.parse((window.localStorage.getItem(`winners-courses-${selectedDate}`) || window.localStorage.getItem("winners-courses") || "null")) as MasterCourse[] | null; return saved ?? seedMasterCourses; } catch { return seedMasterCourses; } }, [selectedDate]);
  const masterCourseData: MasterCourse[] = courses.length ? courses : localMasterCourseData;
  return <><div className="toolbar-row"><div className="filter-tabs"><button className="is-selected">Courses <span>{masterCourseData.length}</span></button><button>Lectures <span>0</span></button></div><button className="outline-button" onClick={() => setLocation("/master-data")}><Database size={14} /> Manage courses</button></div><section className="panel empty-state"><BookOpen size={24} /><h2>No courses for {selectedDate}</h2><p>Add courses in Master Data and create date-wise lectures in Scheduling Control.</p></section></>;
}
function OperationsPage() {
  return <section className="panel empty-state"><Network size={22} /><h2>No resources yet</h2><p>Add halls, studios or online rooms from Master Data.</p></section>;
}
function NotesPage({ slots = [] }: { slots?: Slot[] }) {
  const rows = slots.filter((slot) => slot.mode === "Online");
  return <section className="panel empty-state"><FileCheck2 size={22} /><h2>{rows.length ? "No notes uploaded yet" : "No online classes yet"}</h2><p>PDF and online-note tracking will appear here after an online class is scheduled.</p></section>;
}
function AnalyticsPage({ faculty = [], slots = [] }: { faculty?: Faculty[]; slots?: Slot[] }) {
  return <section className="panel analytics-grid"><div className="panel"><span className="section-kicker">FACULTY CAPACITY</span><h2>{faculty.length}</h2><p>Faculty records loaded from database</p></div><div className="panel"><span className="section-kicker">SCHEDULED CLASSES</span><h2>{slots.filter((slot) => slot.status !== "lunch").length}</h2><p>Classes for the selected date</p></div><div className="panel"><span className="section-kicker">ONLINE / OFFLINE</span><h2>{slots.filter((slot) => slot.mode === "Online").length} / {slots.filter((slot) => slot.mode === "Offline").length}</h2><p>Mode distribution</p></div></section>;
}
function AuditPage({ entries, selectedDate }: { entries: typeof auditEntries; selectedDate: string }) {
  const [query, setQuery] = useState("");
  const filtered = entries.filter((entry) => `${entry.actor} ${entry.action} ${entry.entity}`.toLowerCase().includes(query.toLowerCase()));
  return <><div className="toolbar-row"><label className="search-field"><Search size={15} /><input placeholder="Search actor, action or record" value={query} onChange={(event) => setQuery(event.target.value)} /></label></div><section className="panel empty-state"><ShieldCheck size={22} /><h2>{filtered.length ? `${filtered.length} changes on ${selectedDate}` : `No audit activity on ${selectedDate}`}</h2><p>Audit entries will appear after a Master Data, attendance or scheduling action is completed.</p></section></>;
}
function SettingsPage({ role }: { role: Role }) {
  const locked = role !== "Master Admin";
  const [users, setUsers] = useState<Array<{ id: string; dbId?: number; name: string; email: string; dashboard: Role; dashboards?: Role[]; password: string; accessUrl: string }>>(() => { try { return (JSON.parse(window.localStorage.getItem("winners-users") ?? "[]") as Array<{ password?: string; [key: string]: unknown }>).map((item) => ({ ...item, password: "" })) as Array<{ id: string; dbId?: number; name: string; email: string; dashboard: Role; dashboards?: Role[]; password: string; accessUrl: string }>; } catch { return []; } });
  const [userFormOpen, setUserFormOpen] = useState(false);
  const [userEdit, setUserEdit] = useState<string | null>(null);
  const [userForm, setUserForm] = useState({ name: "", email: "", userId: "", password: "", dashboard: "Admin" as Role, dashboards: ["Admin"] as Role[] });
  const createUserMutation = trpc.winners.createUser.useMutation();
  const usersQuery = trpc.winners.users.useQuery(undefined, { retry: false, refetchOnWindowFocus: false });
  const deleteUserMutation = trpc.winners.deleteUser.useMutation();
  useEffect(() => { try { window.localStorage.setItem("winners-users", JSON.stringify(users.map(({ password: _password, ...user }) => user))); } catch { /* preview storage can be unavailable */ } }, [users]);
  useEffect(() => { if (usersQuery.data?.source !== "database") return; setUsers(usersQuery.data.users.map((user) => ({ dbId: user.id, id: user.loginId || `db-${user.id}`, name: user.name || "Dashboard user", email: user.email || "", dashboard: user.dashboard, dashboards: [user.dashboard], password: "", accessUrl: `${window.location.origin}/access/${user.loginId || user.id}` }))); }, [usersQuery.data]);
  const saveUser = async () => {
    if (!userForm.name.trim() || !userForm.email.trim()) { toast.error("User name and email are required"); return; }
    if (!userForm.dashboards.length) { toast.error("Select at least one dashboard"); return; }
    if (userEdit) {
      setUsers((current) => current.map((item) => item.id === userEdit ? { ...item, name: userForm.name.trim(), email: userForm.email.trim(), dashboard: userForm.dashboards[0] || userForm.dashboard, dashboards: userForm.dashboards } : item));
      toast.success("Dashboard user updated locally; create a new account to change its password");
    } else {
      const id = userForm.userId.trim() || `wc-${Date.now().toString(36)}`;
      const password = userForm.password.trim();
      if (password.length < 8) { toast.error("Set a user password of at least 8 characters"); return; }
      try {
        await createUserMutation.mutateAsync({ name: userForm.name.trim(), email: userForm.email.trim(), loginId: id, password, dashboard: userForm.dashboards[0] || userForm.dashboard });
        const accessUrl = `${window.location.origin}/access/${id}`;
        setUsers((current) => [...current, { ...userForm, id, password, accessUrl, dashboard: userForm.dashboards[0] || userForm.dashboard, dashboards: userForm.dashboards, name: userForm.name.trim(), email: userForm.email.trim() }]);
        toast.success(`${userForm.name} was assigned to the ${userForm.dashboard} dashboard and saved permanently`);
      } catch { toast.error("Could not create the user. Check that the ID is unique and the database is available."); return; }
    }
    setUserForm({ name: "", email: "", userId: "", password: "", dashboard: "Admin", dashboards: ["Admin"] }); setUserEdit(null); setUserFormOpen(false);
  };
  return <><section className="settings-grid"><div className="panel settings-panel"><div className="panel-heading"><div><span className="section-kicker"><SlidersHorizontal size={14} /> OPERATING RULES</span><h2>Schedule guardrails</h2></div><StatusPill tone="green">Active</StatusPill></div><div className="setting-row"><div><strong>Daily class capacity</strong><span>Maximum classes that can be assigned in a day</span></div><div className="setting-control"><strong>8</strong><span>classes</span><Edit3 size={14} /></div></div><div className="setting-row"><div><strong>Operating window</strong><span>Faculty duty and class assignment window</span></div><div className="setting-control"><strong>08:00 – 20:00</strong><Edit3 size={14} /></div></div><div className="setting-row"><div><strong>Faculty setup / recovery buffer</strong><span>10 minutes total: 5 minutes before and 5 minutes after every class; lunch is not a fixed rule</span></div><div className="setting-control"><StatusPill tone="green">10 minutes</StatusPill><Clock3 size={14} /></div></div></div><div className="panel settings-panel"><div className="panel-heading"><div><span className="section-kicker"><ShieldCheck size={14} /> ROLE MATRIX</span><h2>Who can do what</h2></div><StatusPill tone="red">Master Admin</StatusPill></div><div className="permission-list">{[["Master Admin", "Everything", "Full control"], ["Admin", "Schedule, attendance, notes", "Manage"], ["Teacher / Operator", "Own lectures and notes", "Limited"], ["Analysis Dashboard", "Read-only insights", "View"], ["Live Display", "Current schedule", "View"]].map(([name, access, level]) => <div className="permission-row" key={name}><div className="avatar avatar--light">{name.split(" ").map((word) => word[0]).join("").slice(0, 2)}</div><div><strong>{name}</strong><span>{access}</span></div><StatusPill tone={level === "Full control" ? "red" : level === "Manage" ? "blue" : "slate"}>{level}</StatusPill></div>)}</div></div></section><section className={`role-warning ${locked ? "" : "role-warning--hidden"}`}><LockKeyhole size={16} /><div><strong>Master Admin access is required to manage users and system rules.</strong><span>Your current role is {role}. Only Master Admin can assign dashboards.</span></div></section><section className="panel user-admin-panel"><div className="panel-heading"><div><span className="section-kicker"><Users size={14} /> USER MANAGEMENT</span><h2>Dashboard access</h2></div><button className="primary-button" disabled={locked} onClick={() => { setUserEdit(null); setUserForm({ name: "", email: "", userId: "", password: "", dashboard: "Admin", dashboards: ["Admin"] }); setUserFormOpen(true); }}><Plus size={14} /> Add user</button></div><p className="page-description user-admin-copy">Master Admin can assign a specific dashboard. The assignment controls role-based navigation and permission checks.</p>{users.length === 0 ? <div className="empty-state">No extra users yet. Add a user and assign a dashboard.</div> : <div className="permission-list">{users.map((user) => <div className="permission-row" key={user.email}><div className="avatar avatar--light">{user.name.split(" ").map((word) => word[0]).join("").slice(0, 2)}</div><div><strong>{user.name}</strong><span>{user.email}</span><small>Login ID: {user.id} · Password is protected and cannot be recovered here</small><button className="mini-button" onClick={() => { navigator.clipboard?.writeText(user.accessUrl); toast.success("Limited dashboard URL copied"); }}>Copy URL</button><span className="row-actions"><button className="icon-button" disabled={locked} onClick={() => { setUserEdit(user.id); setUserForm({ name: user.name, email: user.email, userId: user.id, password: user.password, dashboard: user.dashboard, dashboards: user.dashboards || [user.dashboard] }); setUserFormOpen(true); }} title="Edit user"><Edit3 size={14} /></button><button className="icon-button icon-button--danger" disabled={locked} onClick={() => { if (window.confirm(`Delete ${user.name}?`)) { void (async () => { try { if (user.dbId) await deleteUserMutation.mutateAsync({ id: user.dbId }); setUsers((current) => current.filter((item) => item.id !== user.id)); toast.success("Dashboard user deleted permanently"); } catch { toast.error("Could not delete this dashboard user"); } })(); } }} title="Delete user"><Trash2 size={14} /></button></span></div><StatusPill tone="blue">{(user.dashboards || [user.dashboard]).join(" · ")}</StatusPill></div>)}</div>}</section>{userFormOpen && <div className="modal-backdrop" onClick={() => setUserFormOpen(false)}><div className="edit-drawer" onClick={(event) => event.stopPropagation()}><div className="drawer-head"><div><span className="section-kicker section-kicker--red">USER MANAGEMENT</span><h2>{userEdit ? "Edit dashboard user" : "Add dashboard user"}</h2></div><button className="icon-button" onClick={() => setUserFormOpen(false)}><X size={17} /></button></div><p className="page-description">Choose exactly which workspace this user can open.</p><label className="form-label">Full name<input value={userForm.name} onChange={(event) => setUserForm((form) => ({ ...form, name: event.target.value }))} /></label><label className="form-label">Email<input type="email" value={userForm.email} onChange={(event) => setUserForm((form) => ({ ...form, email: event.target.value }))} /></label><label className="form-label">User ID<input value={userForm.userId} onChange={(event) => setUserForm((form) => ({ ...form, userId: event.target.value }))} placeholder="At least 8 characters" /></label><label className="form-label">Password<input type="text" value={userForm.password} onChange={(event) => setUserForm((form) => ({ ...form, password: event.target.value }))} placeholder="Leave blank to generate" /></label><label className="form-label">Dashboard / role<select value={userForm.dashboard} onChange={(event) => setUserForm((form) => { const dashboard = event.target.value as Role; return { ...form, dashboard, dashboards: Array.from(new Set([...form.dashboards, dashboard])) }; })}>{["Admin", "Teacher / Operator", "Analysis Dashboard", "Live Display"].map((item) => <option key={item}>{item}</option>)}</select></label><div className="platform-checks"><span className="form-label-title">Additional dashboards</span>{["Admin", "Teacher / Operator", "Analysis Dashboard", "Live Display"].map((item) => <label key={item}><input type="checkbox" checked={userForm.dashboards.includes(item as Role)} onChange={(event) => setUserForm((form) => ({ ...form, dashboards: event.target.checked ? Array.from(new Set([...form.dashboards, item as Role])) : form.dashboards.filter((roleItem) => roleItem !== item) }))} /> {item}</label>)}</div><button className="primary-button primary-button--wide" onClick={saveUser}><Save size={14} /> {userEdit ? "Update user access" : "Save user access"}</button></div></div>}<section className="panel integration-panel"><div className="panel-heading"><div><span className="section-kicker"><Database size={14} /> DATA READINESS</span><h2>Google Sheets mapping</h2></div><StatusPill tone="amber">Future connector</StatusPill></div><div className="integration-tabs"><span className="is-active">Faculty</span><span>Courses</span><span>Lectures</span><span>Schedule</span><span>Notes</span><span>AuditLog</span></div><p>Google Sheets mapping is an optional connector: Faculty, Courses, Lectures, Schedule, Notes and AuditLog tabs can receive the same date-wise rows through a Google Apps Script webhook. It is not active yet, so the app database remains the source of truth; once authorized, changes can be mirrored to Sheets for reporting.</p></section></>;
}
function LivePage({ slots }: { slots: Slot[] }) {
  if (!slots.length) return <div className="live-screen"><div className="live-screen-top"><Wordmark compact /><span><span className="live-dot" /> LIVE DISPLAY</span></div><section className="panel empty-state"><Radio size={22} /><h2>No live class scheduled</h2><p>Live Display will populate after a class is scheduled for the selected date.</p></section></div>;
  const live = slots.find((slot) => slot.status === "live") ?? slots[0];
  return <div className="live-screen"><div className="live-screen-top"><Wordmark compact /><span><span className="live-dot" /> LIVE DISPLAY</span></div><div className="live-current"><div className="live-current-main"><span className="section-kicker section-kicker--red"><Radio size={14} /> ON AIR NOW</span><p className="live-time">{live.time}</p><h2>{live.lecture}</h2><p>{live.course} · {live.subject}</p><div className="live-details"><span><GraduationCap size={16} /> {live.faculty}</span><span><Network size={16} /> {live.location}</span><span><UserCog size={16} /> {live.operator}</span></div></div></div></div>;
}
function AccessPortalPage({ userId }: { userId: string }) { const [password, setPassword] = useState(""); const [unlocked, setUnlocked] = useState(false); const [user, setUser] = useState<{ id: string; name: string; email: string; dashboard: Role; dashboards?: Role[]; password: string; accessUrl: string } | null>(null); useEffect(() => { try { const users = JSON.parse(window.localStorage.getItem("winners-users") ?? "[]") as Array<{ id: string; name: string; email: string; dashboard: Role; password: string; accessUrl: string; dashboards?: Role[] }>; setUser(users.find((item) => item.id === userId) ?? null); } catch { setUser(null); } }, [userId]); if (!user) return <div className="login-screen"><div className="login-card"><Wordmark /><h1>Access link not found.</h1><p>Ask the Master Admin for a new dashboard access link.</p></div></div>; const links: Record<Role, string[]> = { "Master Admin": ["/"], "Admin": ["/", "/schedule", "/attendance", "/scheduling", "/notes"], "Teacher / Operator": ["/", "/schedule", "/scheduling", "/attendance", "/notes"], "Analysis Dashboard": ["/", "/scheduling", "/analytics", "/audit"], "Live Display": [] }; return <div className="login-screen"><div className="login-card"><Wordmark /><span className="section-kicker">LIMITED DASHBOARD ACCESS</span><h1>{(user.dashboards || [user.dashboard]).join(" + ")}</h1><p>{user.name} · {user.email}</p>{!unlocked ? <><label className="form-label">Password<input type="password" value={password} onChange={(event) => setPassword(event.target.value)} /></label><button className="primary-button primary-button--wide" onClick={() => password === user.password ? (() => { try { window.localStorage.setItem("winners-access-role", (user.dashboards || [user.dashboard])[0]); window.localStorage.setItem("winners-access-roles", JSON.stringify(user.dashboards || [user.dashboard])); window.localStorage.setItem("winners-limited-access", "true"); } catch { /* ignore */ } setUnlocked(true); })() : toast.error("Incorrect access password")}>Open assigned dashboard <ArrowRight size={15} /></button></> : <div className="permission-list">{Array.from(new Set((user.dashboards || [user.dashboard]).flatMap((dashboard) => links[dashboard]))).map((link) => <button className="outline-button" key={link} onClick={() => { window.location.href = link; }}>{link === "/" ? "Overview" : link.slice(1).replace("-", " ")}</button>)}</div>}<div className="login-rule"><LockKeyhole size={14} /> Only {(user.dashboards || [user.dashboard]).join(" + ")} permissions are available.</div></div></div>; }
function MasterAdminGate({ onUnlock, authorized, onLogin, verifying }: { onUnlock: (password: string) => Promise<void>; authorized: boolean; onLogin: () => void; verifying: boolean }) {
  const [password, setPassword] = useState("");
  if (!authorized) return <div className="login-screen"><div className="login-card master-admin-gate"><Wordmark /><span className="section-kicker section-kicker--red">MASTER ADMIN SECURITY</span><h1>Sign in to continue</h1><p>Master Admin access is controlled by the server session. Direct URLs cannot grant access.</p><button className="primary-button primary-button--wide" onClick={onLogin}>Continue with Manus <ArrowRight size={15} /></button><div className="login-rule"><LockKeyhole size={14} /> No password or role is stored in client source.</div></div></div>;
  return <div className="login-screen"><div className="login-card master-admin-gate"><Wordmark /><span className="section-kicker section-kicker--red">MASTER ADMIN SECURITY</span><h1>Enter Master Admin password</h1><p>Your account has the required role. Enter the server-verified password to open this protected workspace.</p><label className="form-label">Password<input autoFocus autoComplete="current-password" type="password" value={password} onChange={(event) => setPassword(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter" && password && !verifying) void onUnlock(password); }} /></label><button className="primary-button primary-button--wide" disabled={!password || verifying} onClick={() => void onUnlock(password)}>{verifying ? "Verifying…" : "Unlock Master Admin dashboard"} <ArrowRight size={15} /></button><div className="login-rule"><LockKeyhole size={14} /> Password verification runs on the server and is never stored in client source.</div></div></div>;
}
function LoginPage() {
  return <div className="login-screen"><div className="login-card"><Wordmark /><span className="section-kicker">INTERNAL ACADEMIC OPERATIONS</span><h1>Keep every class connected.</h1><p>Sign in with your Manus account to manage attendance, schedules, substitutes and live classroom operations.</p><button className="primary-button primary-button--wide" onClick={() => { try { startLogin(); } catch { toast.error("Manus login is not configured in this preview"); } }}>Continue with Manus <ArrowRight size={15} /></button><div className="login-rule"><ShieldCheck size={14} /> Role-based access · Audit-ready by default</div></div></div>;
}

export default function Home() {
  const [location, setLocation] = useLocation();
  const auth = useAuth({ redirectOnUnauthenticated: false });
  const masterAdminPasswordMutation = trpc.auth.verifyMasterAdminPassword.useMutation();
  const attendanceMutation = trpc.winners.markAttendance.useMutation();
  const canReadAudit = auth.user?.appRole === "Master Admin" || auth.user?.appRole === "Admin" || auth.user?.appRole === "Analysis Dashboard" || auth.user?.role === "admin";
  const auditQuery = trpc.winners.audit.useQuery({ limit: 50 }, { enabled: canReadAudit, retry: false, refetchOnWindowFocus: false });
  const [siteSession, setSiteSession] = useState<SiteSession | null>(() => { try { return JSON.parse(sessionStorage.getItem("winners-site-session") || "null") as SiteSession | null; } catch { return null; } });
  const [role, setRole] = useState<Role>(() => { try { const stored = window.localStorage.getItem("winners-access-role") as Role | null; const limited = window.localStorage.getItem("winners-limited-access") === "true"; return stored && !(stored === "Master Admin" && !limited) ? stored : "Teacher / Operator"; } catch { return "Teacher / Operator"; } });
  const [masterAdminUnlocked, setMasterAdminUnlocked] = useState(false);
  useEffect(() => { if (location !== "/master-admin") setMasterAdminUnlocked(false); }, [location]);
  const today = new Date().toISOString().slice(0, 10);
  const [selectedDate, setSelectedDate] = useState(() => { try { return window.localStorage.getItem("winners-selected-date") || today; } catch { return today; } });
  const bootstrapQuery = trpc.winners.bootstrap.useQuery({ date: selectedDate }, { retry: false, refetchOnWindowFocus: false });
  const loadDateFaculty = (date: string) => { try { const deleted = new Set<string>(JSON.parse(window.localStorage.getItem("winners-deleted-master") || "[]")); const saved = window.localStorage.getItem(`winners-faculty-${date}`) || window.localStorage.getItem("winners-faculty"); const source = saved ? JSON.parse(saved) as Faculty[] : seedFaculty; return source.filter((item) => !deleted.has(`faculty:${item.code}`)).map((item) => item.status === "pending" ? { ...item, status: "present" as const, availability: item.availability || "08:00–20:00" } : item); } catch { return seedFaculty.map((item) => item.status === "pending" ? { ...item, status: "present" as const } : item); } };
  const loadDateSlots = (date: string) => { try { const saved = window.localStorage.getItem(`winners-slots-${date}`); return saved ? JSON.parse(saved) as Slot[] : initialSlots; } catch { return initialSlots; } };
  const hydratedDate = useRef(selectedDate);
  const [faculty, setFaculty] = useState<Faculty[]>(() => loadDateFaculty(selectedDate));
  const [slots, setSlots] = useState<Slot[]>(() => loadDateSlots(selectedDate));
  const [masterCourses, setMasterCourses] = useState<MasterCourse[]>([]);
  const [facultyCourseMaps, setFacultyCourseMaps] = useState<FacultyCourseMap[]>([]);
  const [resources, setResources] = useState<ResourceRecord[]>([]);
  const [editing, setEditing] = useState<Faculty | null>(null);
  const [editingForm, setEditingForm] = useState({ mode: "Offline" as Faculty["mode"], availability: "", subject: "" });
  const [substituteFor, setSubstituteFor] = useState<string | null>(null);
  useEffect(() => { try { window.localStorage.setItem("winners-selected-date", selectedDate); } catch { /* preview storage may be unavailable */ } }, [selectedDate]);
  useEffect(() => { if (!auditQuery.data?.entries) return; setActivity(auditQuery.data.entries.map((entry) => ({ time: entry.createdAt ? new Date(entry.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "Now", actor: entry.actorName || "System", action: entry.action, entity: entry.entityId || entry.entity, tone: entry.action.toLowerCase().includes("delete") ? "red" : "blue" }))); }, [auditQuery.data]);
  useEffect(() => { if (hydratedDate.current !== selectedDate) return; try { window.localStorage.setItem(`winners-faculty-${selectedDate}`, JSON.stringify(faculty)); window.localStorage.setItem(`winners-slots-${selectedDate}`, JSON.stringify(slots)); } catch { /* preview storage may be unavailable */ } }, [faculty, slots, selectedDate]);
  useEffect(() => {
    const data = bootstrapQuery.data;
    if (!data || data.source !== "database") return;
    const attendanceByFaculty = new Map(data.attendance.map((row) => [row.facultyId, row]));
    setFaculty(data.faculty.map((row) => { const attendance = attendanceByFaculty.get(row.id); return { id: row.id, code: row.employeeCode, name: row.name, initials: row.initials, subject: row.primarySubject, mode: row.defaultMode === "online" ? "Online" : row.defaultMode === "offline" ? "Offline" : "Hybrid", status: attendance?.status === "present" ? "present" : attendance?.status === "absent" ? "absent" : "pending", availability: attendance?.fromTime && attendance?.toTime ? `${attendance.fromTime}–${attendance.toTime}` : row.availability, sessions: 0, replacementEligible: Boolean(row.replacementEligible), maxLectures: row.maxLectures, notes: row.notes || "" }; }));
    setMasterCourses(data.courses.map((row) => ({ id: row.code, name: row.name, mode: row.mode === "online" ? "Online" : row.mode === "offline" ? "Offline" : "Hybrid", status: row.status === "active" ? "Active" : row.status === "draft" ? "Upcoming" : "Archived", notes: row.notes || "", subject: row.subject, branch: row.branch })));
    setFacultyCourseMaps(data.mappings.map((row) => { const facultyRow = data.faculty.find((item) => item.id === row.facultyId); const courseRow = data.courses.find((item) => item.id === row.courseId); return { facultyId: facultyRow?.employeeCode || String(row.facultyId), facultyName: facultyRow?.name || "", courseId: courseRow?.code || String(row.courseId), courseName: courseRow?.name || "", allowed: row.allowed ? "Yes" : "No", priority: row.priority === "primary" ? "Primary" : row.priority === "backup" ? "Backup" : "—", notes: row.notes || "" }; }));
    setResources(data.resources.map((row) => ({ code: row.resourceCode, name: row.resourceName, type: row.type === "hall" ? "Hall" : row.type === "studio" ? "Studio" : "Online Room", status: row.status === "available" ? "Available" : row.status === "live" ? "Live" : "Maintenance", buildingGroup: row.buildingGroup, availabilityFrom: row.availabilityFrom, availabilityTo: row.availabilityTo, notes: row.notes || "" })));
    setSlots(data.schedule.map((row, index) => ({ id: row.id, time: `${row.startTime}–${row.endTime}`, label: `Slot ${String(index + 1).padStart(2, "0")}`, course: row.courseNames, lecture: row.lectureTitle, subject: row.subject, faculty: row.facultyName, mode: row.mode === "online" ? "Online" : "Offline", location: row.resourceCode || "", operator: row.operatorName || "", color: (["red", "blue", "slate", "teal"] as const)[index % 4], status: row.status === "done" ? "done" : row.status === "cancelled" ? "upcoming" : index === 0 ? "next" : "upcoming", notes: row.pdfUploaded ? "uploaded" : row.mode === "online" ? "pending" : "not-required", durationMinutes: row.actualDurationMinutes || undefined, resourceType: row.resourceType === "hall" ? "Hall" : row.resourceType === "studio" ? "Studio" : row.resourceType === "online_room" ? "Online Room" : undefined, resourceCode: row.resourceCode || undefined })));
  }, [bootstrapQuery.data]);
  const [activity, setActivity] = useState(auditEntries);
  const path = location === "/login" ? "/login" : (pageMeta[location] ? location : "/");
  const isLive = path === "/live";
  const presentCount = useMemo(() => faculty.filter((person) => person.status === "present").length, [faculty]);
  const recordActivity = (action: string, entity: string, tone: string = "blue") => setActivity((current) => [{ time: "Now", actor: role, action, entity, tone }, ...current].slice(0, 20));
  const markAll = () => { setFaculty((current) => current.map((person) => ({ ...person, status: "present", availability: "08:00–20:00" }))); faculty.forEach((person) => void attendanceMutation.mutateAsync({ facultyId: person.id, status: "present", date: selectedDate, fromTime: "08:00", toTime: "20:00" }).catch(() => undefined)); recordActivity("Marked attendance", `${faculty.length} faculty roster`, "green"); toast.success(`${faculty.length} faculty marked present · schedule is ready`); };
  const markOne = (id: number, status: Faculty["status"]) => { const person = faculty.find((item) => item.id === id); const dbStatus = status === "half-day" ? "pending" : status; setFaculty((current) => current.map((item) => item.id === id ? { ...item, status, availability: status === "present" ? "08:00–20:00" : status === "half-day" ? "08:00–13:00" : "Substitute needed" } : item)); void attendanceMutation.mutateAsync({ facultyId: id, status: dbStatus, date: selectedDate, fromTime: "08:00", toTime: status === "half-day" ? "13:00" : "20:00", replacementMode: status === "absent" ? "required" : "not_required" }).catch(() => toast.error("Attendance changed locally but could not be saved to the database")); recordActivity("Marked attendance", person?.name ?? `Faculty ${id}`, status === "absent" ? "red" : "green"); toast.success("Attendance updated · schedule inputs refreshed"); };
  const generate = () => { setSlots((current) => current.map((slot) => slot.status === "upcoming" ? { ...slot, status: "upcoming" } : slot)); recordActivity("Generated daily schedule", `${slots.length} slots · 10-minute faculty buffer`, "blue"); toast.success("Schedule generated · faculty buffers applied"); };
  const unlockMasterAdmin = async (password: string) => { try { await masterAdminPasswordMutation.mutateAsync({ password }); setRole("Master Admin"); setMasterAdminUnlocked(true); toast.success("Master Admin access unlocked"); } catch { toast.error("Incorrect Master Admin password"); } };
  if (location.startsWith("/access/")) return <SiteLoginPage userOnly initialUserId={decodeURIComponent(location.slice("/access/".length))} onSuccess={(session) => { setSiteSession(session); setRole(session.role); setLocation("/"); }} />;
  const handleSiteLogin = (session: SiteSession) => { setSiteSession(session); setRole(session.role); if (session.kind === "master") setMasterAdminUnlocked(true); setLocation("/"); };
  if (location === "/master-admin" && !masterAdminUnlocked) return <SiteLoginPage masterOnly onSuccess={(session) => { setMasterAdminUnlocked(true); handleSiteLogin(session); }} />;
  if (location === "/login") return <SiteLoginPage onSuccess={handleSiteLogin} />;
  const validServerSession = Boolean(siteSession && auth.user && ((siteSession.kind === "master" && auth.user.id === 0 && auth.user.loginMethod === "master-password") || (siteSession.kind === "user" && auth.user.id > 0 && auth.user.loginMethod === "master-admin")));
  if (!validServerSession && !location.startsWith("/access/")) return <SiteLoginPage onSuccess={handleSiteLogin} />;
  if (path === "/login") return <LoginPage />;
  if (isLive) return <LivePage slots={slots} />;
  const allowedPaths: Record<Role, string[]> = { "Master Admin": Object.keys(pageMeta), "Admin": ["/", "/schedule", "/scheduling", "/attendance", "/faculty", "/master-data", "/courses", "/notes", "/analytics", "/audit"], "Teacher / Operator": ["/", "/schedule", "/scheduling", "/attendance", "/notes"], "Analysis Dashboard": ["/", "/scheduling", "/analytics", "/audit"], "Live Display": [] };
  const hasAccess = allowedPaths[role].includes(path); const isHistorical = selectedDate < new Date().toISOString().slice(0, 10); const canEditHistorical = role === "Master Admin";
  const page = !hasAccess ? <div className="panel rule-callout"><LockKeyhole size={18} /><div><strong>Role access is limited for this view.</strong><span>{role} can open only its assigned workspace modules.</span></div></div> : path === "/" ? <Overview slots={slots} attendance={faculty} onGenerate={generate} onMarkAll={markAll} onNavigate={setLocation} activity={activity} selectedDate={selectedDate} /> : path === "/schedule" ? <SchedulePage slots={slots} onGenerate={generate} /> : path === "/scheduling" ? <Scheduling slots={slots} faculty={faculty} masterCourses={masterCourses} mappings={facultyCourseMaps} resources={resources} onGenerate={generate} onAudit={recordActivity} readOnly={role === "Analysis Dashboard" || (isHistorical && !canEditHistorical)} date={selectedDate} onDateChange={setSelectedDate} /> : path === "/attendance" ? <AttendancePage faculty={faculty} onChange={markOne} onMarkAll={markAll} onSubstitute={(name) => setSubstituteFor(name)} /> : path === "/faculty" ? <FacultyPage faculty={faculty} canEdit={role === "Master Admin" && (!isHistorical || canEditHistorical)} onEdit={(person) => { setEditing(person); setEditingForm({ mode: person.mode, availability: person.availability, subject: person.subject }); }} /> : path === "/master-data" ? <MasterData faculty={faculty} setFaculty={setFaculty} onAudit={recordActivity} date={selectedDate} allowAdd={role === "Master Admin"} allowEdit={role === "Master Admin" || (role === "Admin" && !isHistorical)} allowDelete={role === "Master Admin"} /> : path === "/courses" ? <CoursesPage selectedDate={selectedDate} courses={masterCourses} /> : path === "/notes" ? <NotesPage slots={slots} /> : path === "/analytics" ? <AnalyticsPage faculty={faculty} slots={slots} /> : path === "/audit" ? <AuditPage entries={activity} selectedDate={selectedDate} /> : <SettingsPage role={role} />;
  const substituteCandidates = substituteFor ? faculty.filter((person) => person.name !== substituteFor && person.status === "present").slice(0, 4) : [];
  return <Shell path={path} role={role} setRole={(nextRole) => { if (nextRole === "Master Admin" && !(auth.user?.role === "admin" || auth.user?.appRole === "Master Admin")) { toast.error("Master Admin role requires an authenticated server account"); return; } setRole(nextRole); }} selectedDate={selectedDate} onDateChange={setSelectedDate} onExport={() => exportRows(`winners-connect-${selectedDate}`, slots.filter((slot) => slot.status !== "lunch").map((slot) => ({ Date: selectedDate, Time: slot.time, Faculty: slot.faculty, Course: slot.course, Lecture: slot.lecture, Mode: slot.mode, Location: slot.location, Status: slot.status })))}>{page}{editing && <div className="modal-backdrop" onClick={() => setEditing(null)}><div className="edit-drawer" onClick={(event) => event.stopPropagation()}><div className="drawer-head"><div><span className="section-kicker">FACULTY RECORD</span><h2>Edit faculty</h2></div><button className="icon-button" onClick={() => setEditing(null)}><X size={17} /></button></div><div className="drawer-profile"><div className="avatar avatar--red">{editing.initials}</div><div><strong>{editing.name}</strong><span>{editing.code} · {editing.subject}</span></div></div><label className="form-label">Primary mode<select value={editingForm.mode} onChange={(event) => setEditingForm((form) => ({ ...form, mode: event.target.value as Faculty["mode"] }))}><option>Offline</option><option>Online</option><option>Hybrid</option></select></label><label className="form-label">Availability<input value={editingForm.availability} onChange={(event) => setEditingForm((form) => ({ ...form, availability: event.target.value }))} /></label><label className="form-label">Subjects<input value={editingForm.subject} onChange={(event) => setEditingForm((form) => ({ ...form, subject: event.target.value }))} /></label><div className="drawer-note"><LockKeyhole size={14} /> Faculty setup/recovery buffer is 10 minutes total: 5 minutes before and 5 minutes after this class.</div><button className="primary-button primary-button--wide" onClick={() => { setFaculty((current) => current.map((person) => person.id === editing.id ? { ...person, mode: editingForm.mode, availability: editingForm.availability, subject: editingForm.subject } : person)); recordActivity("Updated faculty master", editing.name, "blue"); setEditing(null); toast.success(`${editing.name} updated`); }}>Save changes <Check size={15} /></button></div></div>}{substituteFor && <div className="modal-backdrop" onClick={() => setSubstituteFor(null)}><div className="edit-drawer" onClick={(event) => event.stopPropagation()}><div className="drawer-head"><div><span className="section-kicker section-kicker--red">SUBSTITUTE WORKFLOW</span><h2>Cover absent faculty</h2></div><button className="icon-button" onClick={() => setSubstituteFor(null)}><X size={17} /></button></div><p className="page-description"><strong>{substituteFor}</strong> is absent. Choose a present faculty member to cover the mapped lecture.</p><div className="permission-list">{substituteCandidates.map((candidate) => <div className="permission-row" key={candidate.id}><div className="avatar avatar--light">{candidate.initials}</div><div><strong>{candidate.name}</strong><span>{candidate.subject} · {candidate.sessions} sessions today</span></div><button className="mini-button mini-button--primary" onClick={() => { setSlots((current) => current.map((slot) => slot.faculty === substituteFor ? { ...slot, faculty: candidate.name, substitute: substituteFor } : slot)); recordActivity("Assigned substitute", `${substituteFor} → ${candidate.name}`, "red"); setSubstituteFor(null); toast.success(`${candidate.name} assigned as substitute`); }}>Assign</button></div>)}</div><div className="drawer-note"><LockKeyhole size={14} /> The 10-minute total faculty setup/recovery buffer remains active while replacing a faculty assignment.</div></div></div>}</Shell>;
}
