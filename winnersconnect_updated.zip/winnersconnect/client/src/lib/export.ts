import * as XLSX from "xlsx";

export type ExportRow = Record<string, unknown>;

function safeName(value: string) { return value.toLowerCase().replaceAll(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "winners-connect-export"; }

export function downloadWorkbook(filename: string, rows: ExportRow[], sheetName = "Export") {
  const worksheet = XLSX.utils.json_to_sheet(rows.length ? rows : [{ Message: "No records for this view" }]);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, sheetName.slice(0, 31));
  XLSX.writeFile(workbook, filename.endsWith(".xlsx") ? filename : `${filename}.xlsx`);
}

export function downloadCsv(filename: string, rows: ExportRow[]) {
  const worksheet = XLSX.utils.json_to_sheet(rows.length ? rows : [{ Message: "No records for this view" }]);
  const csv = XLSX.utils.sheet_to_csv(worksheet);
  const blob = new Blob(["\ufeff", csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a"); link.href = url; link.download = filename.endsWith(".csv") ? filename : `${filename}.csv`; link.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 0);
}

export function exportRows(title: string, rows: ExportRow[], format: "xlsx" | "csv" = "xlsx") {
  const filename = `${safeName(title)}-${new Date().toISOString().slice(0, 10)}`;
  if (format === "csv") downloadCsv(filename, rows); else downloadWorkbook(filename, rows, title);
}

export async function parseSpreadsheet(file: File): Promise<ExportRow[]> {
  const workbook = XLSX.read(await file.arrayBuffer(), { type: "array", cellDates: false });
  const firstSheet = workbook.SheetNames[0];
  if (!firstSheet) return [];
  return XLSX.utils.sheet_to_json<ExportRow>(workbook.Sheets[firstSheet], { defval: "" });
}
