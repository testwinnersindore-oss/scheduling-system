export type Role = "Master Admin" | "Admin" | "Teacher / Operator" | "Analysis Dashboard" | "Live Display";
export type AttendanceStatus = "present" | "absent" | "half-day" | "pending";

export type Faculty = {
  id: number;
  name: string;
  initials: string;
  subject: string;
  code: string;
  mode: "Online" | "Offline" | "Hybrid";
  status: AttendanceStatus;
  availability: string;
  sessions: number;
  replacementEligible: boolean;
  maxLectures: number;
  notes?: string;
};

export type Slot = {
  id: number;
  time: string;
  label: string;
  course: string;
  lecture: string;
  subject: string;
  faculty: string;
  mode: "Online" | "Offline";
  location: string;
  operator: string;
  color: "red" | "blue" | "slate" | "teal";
  status: "live" | "next" | "upcoming" | "done" | "lunch";
  notes: "uploaded" | "pending" | "not-required";
  substitute?: string;
  durationMinutes?: number;
  resourceType?: "Hall" | "Studio" | "Online Room";
  resourceCode?: string;
};

export const timeSlots = [
  { id: 1, time: "08:00–09:15", label: "Slot 01" },
  { id: 2, time: "09:20–10:35", label: "Slot 02" },
  { id: 3, time: "10:40–11:55", label: "Slot 03" },
  { id: 4, time: "12:00–12:55", label: "Slot 04" },
  { id: 5, time: "13:00–13:40", label: "LUNCH", lunch: true },
  { id: 6, time: "13:40–14:55", label: "Slot 05" },
  { id: 7, time: "15:00–16:15", label: "Slot 06" },
  { id: 8, time: "16:20–17:35", label: "Slot 07" },
  { id: 9, time: "17:40–18:55", label: "Slot 08" },
];

export const faculty: Faculty[] = [];
export const initialSlots: Slot[] = [];

export const auditEntries: { time: string; actor: string; action: string; entity: string; tone: string }[] = [];

export const courses: { name: string; code: string; students: number; lectures: number; lead: string }[] = [];

export const locations: { name: string; type: string; halls: string; status: string }[] = [];

export const quickMetrics: { label: string; value: string; detail: string; tone: string }[] = [];
