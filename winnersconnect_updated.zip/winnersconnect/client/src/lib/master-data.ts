export type MasterCourse = {
  id: string;
  name: string;
  mode: "Online" | "Offline" | "Hybrid" | "Offline / Hybrid";
  status: "Upcoming" | "Live" | "Active" | "Draft" | "Archived";
  platforms?: ("YouTube" | "App")[];
  notes: string;
  subject?: string;
  branch?: string;
};
export type FacultyCourseMap = { facultyId: string; facultyName: string; courseId: string; courseName: string; allowed: "Yes" | "No"; priority: "Primary" | "Backup" | "—"; notes: string };
export type ResourceRecord = { code: string; name: string; type: "Hall" | "Studio" | "Online Room"; buildingGroup: string; availabilityFrom: string; availabilityTo: string; status: "Available" | "Live" | "Maintenance"; notes: string };
export type AttendanceRecord = { date: string; facultyId: string; facultyName: string; status: "Present" | "Absent" | "Pending"; fromTime: string; toTime: string; replacementMode: "Not required" | "Required" | "Assigned"; notes: string; updatedAt: string };
export type ReplacementRecord = { date: string; time: string; originalFacultyId: string; originalFaculty: string; course: string; subject: string; mode: "Online" | "Offline"; resource: string; replacementFacultyId: string; replacementFaculty: string; reason: string; status: "Assigned" | "Open" | "Declined"; createdAt: string; updatedAt: string };
export const masterCourses: MasterCourse[] = [];
export const facultyCourseMaps: FacultyCourseMap[] = [];
export const resources: ResourceRecord[] = [];
export const ruleCatalog = [
  { rule: "WORK_START", value: "08:00", description: "Faculty working window starts at 8:00 AM" },
  { rule: "WORK_END", value: "20:00", description: "Faculty working window ends at 8:00 PM" },
  { rule: "SETUP_BUFFER", value: "10", description: "Faculty setup/travel buffer before and after each class (minutes)" },
  { rule: "MAX_LECTURES", value: "8", description: "Maximum fixed lectures per faculty/day" },
  { rule: "ONLINE_RESOURCE", value: "STUDIO", description: "Online classes require Studio/online resource" },
  { rule: "OFFLINE_RESOURCE", value: "HALL", description: "Offline classes require Hall resource" },
];
export const attendanceRecords: AttendanceRecord[] = [];
export const replacementRecords: ReplacementRecord[] = [];
