import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/master-admin" component={Home} />
      <Route path="/schedule" component={Home} />
      <Route path="/scheduling" component={Home} />
      <Route path="/attendance" component={Home} />
      <Route path="/master-data" component={Home} />
      <Route path="/faculty" component={Home} />
      <Route path="/courses" component={Home} />
      <Route path="/notes" component={Home} />
      <Route path="/analytics" component={Home} />
      <Route path="/live" component={Home} />
      <Route path="/audit" component={Home} />
      <Route path="/settings" component={Home} />
      <Route path="/login" component={Home} />
      <Route path="/access/:userId" component={Home} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster position="top-right" />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
