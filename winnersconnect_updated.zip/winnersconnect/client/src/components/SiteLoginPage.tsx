import { useState } from "react";
import { ArrowRight, KeyRound, LockKeyhole, UserRound } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import type { Role } from "@/lib/winners-data";

export type SiteSession = { kind: "master" | "user"; role: Role; roles: Role[]; name: string };

function saveSession(session: SiteSession, onSuccess: (session: SiteSession) => void) {
  try { sessionStorage.setItem("winners-site-session", JSON.stringify(session)); } catch { /* storage may be unavailable */ }
  onSuccess(session);
}

export default function SiteLoginPage({ masterOnly = false, userOnly = false, initialUserId = "", onSuccess }: { masterOnly?: boolean; userOnly?: boolean; initialUserId?: string; onSuccess: (session: SiteSession) => void }) {
  const [mode, setMode] = useState<"master" | "user">(masterOnly || !userOnly ? "master" : "user");
  const [masterPassword, setMasterPassword] = useState("");
  const [userId, setUserId] = useState(initialUserId);
  const [userPassword, setUserPassword] = useState("");
  const utils = trpc.useUtils();
  const verifyMaster = trpc.auth.verifyMasterAdminPassword.useMutation();
  const loginUser = trpc.auth.loginUser.useMutation();
  const submitMaster = async () => {
    try {
      await verifyMaster.mutateAsync({ password: masterPassword });
      await utils.auth.me.invalidate();
      saveSession({ kind: "master", role: "Master Admin", roles: ["Master Admin"], name: "Master Admin" }, onSuccess);
      toast.success("Master Admin login successful");
    } catch { toast.error("Incorrect Master Admin password"); }
  };
  const submitUser = async () => {
    try {
      const session = await loginUser.mutateAsync({ loginId: userId.trim(), password: userPassword });
      await utils.auth.me.invalidate();
      saveSession({ kind: "user", role: session.role, roles: session.roles, name: session.name ?? userId.trim() }, onSuccess);
      toast.success(`Welcome, ${session.name}`);
    } catch { toast.error("Invalid user ID or password"); }
  };
  const submit = () => { if (mode === "master") void submitMaster(); else submitUser(); };
  return <div className="login-screen"><div className="login-card master-admin-gate"><div className="brand-mark" aria-label="WiNNERS Institute Indore"><span className="brand-w">W</span><span className="brand-i">i</span><span className="brand-nners">NNERS</span><span className="brand-sub">INSTITUTE · INDORE</span></div><span className="section-kicker section-kicker--red"><LockKeyhole size={14} /> {masterOnly ? "MASTER ADMIN LOGIN" : userOnly ? "ASSIGNED USER LOGIN" : "INTERNAL ACADEMIC OPERATIONS"}</span><h1>{masterOnly ? "Enter Master Admin password" : userOnly ? "Sign in to assigned dashboard" : "Sign in to Winners Connect"}</h1><p>{masterOnly ? "OAuth is not required. Use the protected Master Admin password to continue." : "Every dashboard requires a Master Admin password or an assigned user ID and password."}</p>{!masterOnly && !userOnly && <div className="filter-tabs login-tabs"><button className={mode === "master" ? "is-selected" : ""} onClick={() => setMode("master")}><KeyRound size={13} /> Master Admin</button><button className={mode === "user" ? "is-selected" : ""} onClick={() => setMode("user")}><UserRound size={13} /> User login</button></div>}{mode === "master" ? <><label className="form-label">Master Admin password<input autoFocus type="password" autoComplete="current-password" value={masterPassword} onChange={(event) => setMasterPassword(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter" && masterPassword && !verifyMaster.isPending) submit(); }} /></label><button className="primary-button primary-button--wide" disabled={!masterPassword || verifyMaster.isPending} onClick={submit}>{verifyMaster.isPending ? "Verifying…" : "Login as Master Admin"} <ArrowRight size={15} /></button></> : <><label className="form-label">User ID<input autoFocus value={userId} onChange={(event) => setUserId(event.target.value)} /></label><label className="form-label">Password<input type="password" autoComplete="current-password" value={userPassword} onChange={(event) => setUserPassword(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter" && userId && userPassword) submit(); }} /></label><button className="primary-button primary-button--wide" disabled={!userId || !userPassword || loginUser.isPending} onClick={submit}>{loginUser.isPending ? "Signing in…" : "Login to assigned dashboard"} <ArrowRight size={15} /></button></>}<div className="login-rule"><LockKeyhole size={14} /> No dashboard page is available until a valid login succeeds.</div></div></div>;
}
